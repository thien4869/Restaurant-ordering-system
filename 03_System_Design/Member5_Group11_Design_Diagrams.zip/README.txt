MEMBER 5 – GROUP 11 – REVISED DESIGN DIAGRAMS

Files included:
- DFD_Level_0.drawio / .png: Context diagram (one system process, external actors, labeled flows).
- DFD_Level_1.drawio / .png: Decomposition into account, menu, cart, order, order-history, cancellation, admin order management, kitchen processing, and reporting processes.
- Software_Architecture_3Layer.drawio / .png: Presentation, Business Logic, and Data Access layers with database.
- .xml files are editable draw.io XML exports.

Consistency notes:
1. Level 0 is a context diagram and intentionally contains no data stores.
2. Level 1 contains D1 Users, D2 Menu, D3 Cart, D4 Orders, D5 Order Details, D6 Payments.
3. Member 5 processes are 5.0 View Order History, 6.0 Cancel Order, and 7.0 Manage Order (Admin).
4. Customer cancellation is shown as permitted only when the order status is New, then updated to Canceled, matching the uploaded Member 5 use-case document.
5. Confirm the final status names and the Admin/Restaurant Staff role with the group before submission.

Open .drawio files at https://app.diagrams.net/ using File > Open From > Device.
