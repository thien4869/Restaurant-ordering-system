# Restaurant Order Management System – Đặc tả hệ thống (Group 11)

Bài tập nhóm: đặc tả hệ thống quản lý đặt món cho nhà hàng, làm theo bản mẫu FaceShop.

**File chính:** `docs/System_Specification_Merged_v2.docx` (bản mới nhất). Bản cũ nằm ở `docs/old/`.

## Cấu trúc thư mục
```
docs/                  file Word đã ghép (v2 là bản mới nhất, bản cũ trong old/)
members/
  tv1_tien-anh/        file gốc + images/ của từng thành viên
  tv2_phuc-hoa/
  tv3_huy/
  tv4_phan-duy/
  tv5_thuan-thien/
diagrams/              sơ đồ chung: DFD, kiến trúc 3 lớp (.png + file nguồn)
  old_drafts/          bản cũ, không dùng nữa
```

## Thành viên
| Mã | Tên | Phần phụ trách | Thư mục |
|---|---|---|---|
| tv1 | Nguyen Tien Anh | Group 1: View and Search Menu. Use-case 2-4: Browse Menu, Search Dish, Manage Dish | `members/tv1_tien-anh/` |
| tv2 | Phuc Hoa | Group 2, 3: Cart và Checkout. Use-case 10-11, Class Diagram, ERD, bảng database | `members/tv2_phuc-hoa/` |
| tv3 | Truong Quang Huy | Group 4: Customer Account. Use-case 5-8: Login, Register, Update Profile, Reset Password | `members/tv3_huy/` |
| tv4 | Phan Duy | Group 5: View and Manage Orders. Use-case 12-14: View Order, Cancel Order, Manage Order | `members/tv4_phan-duy/` |
| tv5 | Nguyen Dinh Thuan Thien | Group 6: System Administration (chưa có file gốc trong repo) | `members/tv5_thuan-thien/` |

## Cách thêm file mới
1. Bỏ file vào đúng thư mục `tvN_...` của mình, hình bỏ trong `images/` của thư mục đó.
2. Đặt tên file chữ thường, không dấu, không khoảng trắng, ví dụ `usecase_manage_user.docx`.
3. Khi sửa lại file cũ, chuyển bản cũ vào thư mục `old_version/` rồi mới bỏ bản mới vào.
4. Người ghép file Word cập nhật `docs/` (đổi v2 thành v3...) và chuyển bản cũ vào `docs/old/`.
5. Sơ đồ dùng chung (DFD, kiến trúc) bỏ trong `diagrams/`, không bỏ trong thư mục cá nhân.

## Còn thiếu / cần thống nhất
- Chưa viết: Use-case 9 (Manage User), II. Glossary (xem lại), IV.1 sơ đồ use-case tổng quan, danh sách actor và use-case.
- Class Diagram của tv2 chỉ có 7 lớp (giỏ hàng, đặt hàng), cần gộp với các lớp của nhóm khác.
- `DFD_Level_0` đã sửa chỉ còn Customer, Guest, Admin. `DFD_Level_1` và `Software_Architecture_3Layer` vẫn còn Kitchen Staff và Restaurant Manager, cần sửa cho khớp.
- Thống nhất: tên actor (Customer / Guest / Member / Admin), tên trạng thái đơn hàng (New / Pending / Confirmed...), tên thương hiệu trên các hình giao diện.
- `members/tv4_phan-duy/images/` có 2 bản giao diện (v1, v2), chưa chốt dùng bản nào.
