@echo off
setlocal
chcp 65001 >nul
if not exist build\CMakeCache.txt (
  echo Build folder not found. Run build_windows.bat first.
  exit /b 1
)
ctest --test-dir build -C Release --output-on-failure
endlocal
