@echo off
setlocal
chcp 65001 >nul
where cmake >nul 2>nul
if errorlevel 1 (
  echo CMake is not installed or not in PATH.
  exit /b 1
)
cmake -S . -B build -DTV1_BUILD_CONSOLE_DEMO=ON
if errorlevel 1 exit /b 1
cmake --build build --config Release
if errorlevel 1 exit /b 1
echo Build completed. The UI design/prototype is maintained in Figma.
endlocal
