# TV1 database seed

`seed_menu.sql` contains the 26 sample dishes owned by TV1. It is a SQL fragment, not a full database seed. Run the shared Group 11 schema and category seed first, then append/run this file after categories `Main Course`, `Appetizer`, `Dessert`, and `Drink` exist.

Category IDs are looked up by category name; the seed does not assume that auto-increment IDs are permanently 1–4. It matches TV5's current `products` columns: `code`, `category_id`, `name`, `image`, `price`, `discount`, `status`, `description`, `detail`, `views`, and `sold`.

The dataset contains 26 dishes: 21 AVAILABLE, 3 SOLD_OUT and 2 DISCONTINUED. Dessert is intentionally empty for the empty-category test. Images are NULL placeholders; replace them with real image paths only when the group has suitable image assets.

For the standalone local demo only, `schema_tv5_reference.sql` is a snapshot of the TV5 schema used by the test package and `seed_categories.sql` inserts four categories. These are reference/demo data, not a replacement for the live shared schema or shared `seed.sql`.
