-- Local demo-only category data. Group seed may contain additional data/IDs.
INSERT INTO categories (name) VALUES
  ('Main Course'),
  ('Appetizer'),
  ('Dessert'),
  ('Drink');
