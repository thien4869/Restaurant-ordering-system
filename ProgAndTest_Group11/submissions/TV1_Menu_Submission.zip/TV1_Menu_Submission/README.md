# Group 11 – TV1 Menu Module (C++17)

**Module owner:** TV1 – View and Search Menu / Manage Dishes  
**Project:** Restaurant Order Management System – Group 11  
**UI design:** Figma (the actual screen layout/prototype is maintained separately by the team)

## 1. Scope from the system specification

This module implements four use cases assigned to TV1:

1. **Browse Menu/Product:** Guest and Customer can view dishes by category, see the newest 20 items per page, and sort results by price, discount, or number of orders.
2. **Search Dish:** Search by all or part of a dish name, case-insensitive and Vietnamese-diacritic-insensitive (for example, `pho bo` finds `Phở bò`). Search results are paginated and sortable.
3. **View Dish Details:** Show dish code, name, image, price, discount, status, views, ordered count, short description and full details. Opening the detail view increases `views` by exactly one.
4. **Manage Dishes:** Authorized Admin can view/filter the dish list, add, update, and delete dishes. If the dish is already referenced by an order, deletion changes its status to `DISCONTINUED` so order history remains valid; otherwise the dish and its cart-item references are deleted.

Guest/Customer menu browsing, searching and details do not require login. Admin operations must use the authenticated `Auth` object from TV3. TV1 does not implement login/session or cart/checkout/order functions.

## 2. Business rules implemented

- Page size: **20** dishes.
- Menu/search hides `DISCONTINUED`; `SOLD_OUT` remains visible with its status.
- Sorting supports ascending and descending price, discount and ordered-count. Default order is newest first.
- The shared schema has no `created_at` field for products. For this version, “newest” is represented by descending numeric product code (e.g. MN26 before MN25); this is documented rather than pretending a timestamp exists.
- Money is stored as integer VND in C++, corresponding to `DECIMAL(12,0)` in MySQL.
- Price after discount is calculated through `PriceHelper::priceAfterDiscount`. This package includes a lightweight standalone fallback for local tests; when merging into the group repository, use TV2's official shared `PriceHelper` if it has already been committed and do not keep two implementations.
- Product fields follow TV5's schema: `code`, `category_id`, `name`, `image`, `price`, `discount`, `status`, `description`, `detail`, `views`, `sold`.
- `description` is the short description; `detail` is the full description; `sold` is displayed as `Ordered` per the current group convention.
- SQL exists only in `MenuRepository` and uses `?` parameters. `IDatabase` separates repository/business logic from the underlying database.
- Image selection accepts JPG/JPEG/PNG with a maximum size of 2 MB. The backend stores a relative image path; the application must save the uploaded file under that path.

## 3. Architecture

```text
Figma screens / application route handlers
              |
     Presentation Controllers
              |
          MenuService
       (business rules)
              |
       IMenuRepository
              |
         MenuRepository
              |
           IDatabase
        /           \
  SqliteDatabase   MySqlDatabase
  (local tests)    (group integration)
```

- `src/models/`: `Product`, `Category` and dish statuses.
- `src/common/`: text normalization, VND formatting, price helper and database interfaces/adapters.
- `src/repositories/`: repository interface and parameterized SQL.
- `src/services/`: validation and menu business logic.
- `src/presentation/controllers/`: controller contracts for Figma/application actions.
- `src/integration/`: small adapter to validate TV3's `Auth` object; it does not duplicate authentication.
- `src/presentation/customer/menu/` and `src/presentation/admin/dishes/`: optional console adapter retained only for local demonstration and compatibility tests. It is **not** the intended user interface; Figma is the design/prototype deliverable.

## 4. Figma screen mapping

See [`docs/FIGMA_INTEGRATION.md`](docs/FIGMA_INTEGRATION.md) for a screen-by-screen mapping. The C++ module exposes these controller actions:

| Figma screen/action | Controller method |
|---|---|
| Menu / category / sort / page | `BrowseMenuController::execute` |
| Search results | `SearchDishController::execute` |
| Dish details | `DishDetailsController::execute` |
| Admin dish list and filters | `ManageDishController::list` |
| Add dish | `ManageDishController::add` |
| Edit dish | `ManageDishController::update` |
| Delete confirmation | `ManageDishController::remove` |

Figma itself is a design/prototype tool; it does not execute C++ code. The team's running application/API layer must call these controllers and bind the returned `DishPage` / `Product` data to the Figma-designed screens. Add the team's actual Figma URL to `docs/FIGMA_INTEGRATION.md` before final group submission.

## 5. Build and run locally

### Linux / WSL

Requirements: C++17 compiler, `make`, SQLite development headers/library.

```bash
sudo apt install g++ make libsqlite3-dev
make -C tests/Unit/test_menu clean
make -C tests/Unit/test_menu test
make -C tests/Unit/test_menu demo
```

### CMake

```bash
cmake -S . -B build
cmake --build build -j
ctest --test-dir build --output-on-failure
```

### Windows 11

Install a C++17 compiler (MinGW-w64/MSYS2 or Visual Studio), CMake, and SQLite development library. Open the extracted folder in VS Code, then run `build_windows.bat` and `run_tests.bat`. If the build cannot find `sqlite3.h`/`sqlite3`, install SQLite development files for the same compiler and add them to its include/library paths.

## 6. MySQL integration (TV5)

The MySQL adapter implements the same `IDatabase` interface used by `MenuRepository`. It uses MySQL prepared statements and UTF-8 `utf8mb4` connections. Build the adapter with:

```bash
cmake -S . -B build-mysql -DTV1_WITH_MYSQL=ON -DTV1_BUILD_TESTS=OFF -DTV1_BUILD_CONSOLE_DEMO=OFF
cmake --build build-mysql -j
```

This build requires the MySQL/MariaDB client development package (`mysqlclient` pkg-config entry). The application creates `MySqlDatabase` using its private environment/configuration values, then passes it to `MenuRepository` and `MenuService`. Do not commit passwords or local connection credentials.

**Verification boundary:** The MySQL adapter is compile-checked in this package. A live connection and CRUD test must still be run against the team's actual MySQL instance; this package does not invent credentials or claim a live database run.

The adapter uses `schema.sql` supplied with the group and does not query `products.created_at`. The 26-row sample menu is in `database/seed_menu.sql`; it is a fragment to append after TV5's category inserts in the shared `database/seed.sql`, not a replacement for the team's full seed file.

## 7. Tests and evidence

- **90/90 automated unit tests passed** in the local C++17/SQLite test run (including service, repository/SQLite integration, demo screen adapter, validation, Vietnamese search, pagination, views, Admin restrictions, deletion with order history, and controller handoff).
- Test case workbook: `tests/testcases/TestCases_Menu.xlsx` (64 manual test cases, plus sample data and read-me sheet). Run these against the integrated application and fill in `Actual Result` and `Status`; the workbook is intentionally not pre-filled with guessed PASS results.
- `evidence/` contains local command output. Re-run tests on the student's machine before taking final screenshots for submission.

## 8. Before merging into Group 11

1. Confirm that TV5's current shared schema still matches `database/README.md` and `docs/MYSQL_SCHEMA_MAPPING.md`.
2. Use TV3's actual `Auth.h` and `User.h` in the main repository. The `tv3_copy/` files are test doubles only and must never be copied into production `src/`.
3. Use TV2's official price helper if available; do not overwrite another member's shared files.
4. Append `seed_menu.sql` to the shared seed file only after category rows exist.
5. Run the local unit tests and the manual test cases on the integrated environment; save genuine screenshots/logs.
6. Follow the current `CONVENTIONS.md` Git section: create `feature-menu` and open a Pull Request unless the group has formally changed that rule.

See [`docs/IMPLEMENTATION_REPORT.md`](docs/IMPLEMENTATION_REPORT.md) for the deliverable summary and [`docs/INTEGRATION_CHECKLIST.md`](docs/INTEGRATION_CHECKLIST.md) for the group merge steps.
