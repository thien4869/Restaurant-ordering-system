#pragma once
// Tiện ích nhập liệu dòng lệnh dùng chung cho các màn hình của TV1 (chỉ lo hiển thị/nhập liệu).
#include <cctype>
#include <string>

#include "common/TextHelper.h"

// "c 3" -> cmd="c", arg="3"
inline void splitCommand(const std::string& line, std::string& cmd, std::string& arg) {
  const std::string t = trim(line);
  const auto space = t.find_first_of(" \t");
  cmd = toLowerAscii(space == std::string::npos ? t : t.substr(0, space));
  arg = space == std::string::npos ? "" : trim(t.substr(space + 1));
}

// Số nguyên dương tối đa 9 chữ số; sai định dạng trả false.
inline bool parsePositiveInt(const std::string& text, int& out) {
  const std::string t = trim(text);
  if (t.empty() || t.size() > 9) return false;
  for (unsigned char c : t)
    if (!std::isdigit(c)) return false;
  out = std::stoi(t);
  return out > 0;
}
