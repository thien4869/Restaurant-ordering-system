#include "presentation/admin/dishes/DishManagementScreen.h"

#include <filesystem>

#include "common/FormatHelper.h"
#include "presentation/ConsoleHelper.h"

namespace fs = std::filesystem;

namespace {

// Người dùng gõ 1/2/3 hoặc tên trạng thái -> giá trị lưu CSDL. Chuỗi lạ giữ nguyên để Service báo lỗi.
std::string parseStatusChoice(const std::string& text) {
  const std::string t = toLowerAscii(trim(text));
  if (t == "1" || t == "available") return dish_status::kAvailable;
  if (t == "2" || t == "sold out" || t == "sold_out" || t == "soldout") return dish_status::kSoldOut;
  if (t == "3" || t == "discontinued") return dish_status::kDiscontinued;
  return toUpperAscii(trim(text));
}

}  // namespace

void DishManagementScreen::render() {
  out_ << "\n=== NutriBite Admin - Menu Management ===\n";
  try {
    DishPage r = service_.manageDishes(keyword_, category_id_, status_, page_);
    page_ = r.page;
    out_ << "Total Dishes: " << r.summary.total << " | Available: " << r.summary.available
         << " | Sold Out: " << r.summary.sold_out << " | Discontinued: " << r.summary.discontinued << "\n";
    std::string category_name = "All";
    for (const auto& c : r.categories)
      if (category_id_ == c.id) category_name = c.name;
    out_ << "Filters: search=\"" << keyword_ << "\" | category=" << category_name
         << " | status=" << (status_.empty() ? "All" : dish_status::label(status_)) << "\n"
         << "DISH ID | DISH NAME | CATEGORY | PRICE | DISCOUNT | VIEWS/ORDERED | STATUS\n";
    for (const auto& d : r.items)
      out_ << d.code << " | " << d.name << " | " << d.category_name << " | " << formatVnd(d.price) << " | "
           << d.discount << "% | " << d.views << "/" << d.sold << " | "
           << dish_status::label(d.status) << "\n";
    if (!r.message.empty()) out_ << r.message << "\n";
    out_ << "Page " << r.page << "/" << r.total_pages << "\n";
  } catch (const DataAccessError& e) {
    out_ << e.what() << "\nType 'r' to try again.\n";
  }
  out_ << "Commands: s <keyword> | c <id|all> | t <all|available|sold_out|discontinued> | n/p | "
          "add | edit <code> | del <code> | r=reload | q=back\n";
}

bool DishManagementScreen::ask(const std::string& label, std::string& value) {
  out_ << label;
  if (!value.empty()) out_ << " [" << value << "]";
  out_ << ": ";
  std::string line;
  if (!std::getline(in_, line)) return false;
  line = trim(line);
  if (toLowerAscii(line) == "cancel") return false;
  if (!line.empty()) value = line;  // Enter = giữ giá trị hiện tại
  return true;
}

bool DishManagementScreen::askForm(DishInput& in, bool is_new, std::string& image_path) {
  out_ << "(type 'cancel' at any prompt to cancel; press Enter to keep the value in brackets)\n";
  if (is_new && !ask("Dish ID *", in.code)) return false;
  if (!is_new) out_ << "Dish ID: " << in.code << " (cannot be changed)\n";

  out_ << "Categories:";
  try {
    for (const auto& c : service_.getCategories()) out_ << "  " << c.id << ") " << c.name;
  } catch (const DataAccessError&) {}
  out_ << "\n";
  if (!ask("Category *", in.category_id)) return false;
  if (!ask("Dish Name *", in.name)) return false;
  if (!ask("Price (VND) *", in.price)) return false;
  if (!ask("Discount (%)", in.discount)) return false;

  std::string status_text = in.status.empty() ? "" : dish_status::label(in.status);
  if (!ask("Status * (1=Available, 2=Sold Out, 3=Discontinued)", status_text)) return false;
  in.status = parseStatusChoice(status_text);

  std::string path;
  if (!ask("Image file path (JPG/PNG, max 2MB, Enter to skip)", path)) return false;
  in.image_name.clear();
  in.image_size = 0;
  image_path.clear();
  if (!path.empty()) {
    std::error_code ec;
    if (fs::is_regular_file(path, ec)) {
      image_path = path;
      in.image_name = fs::path(path).filename().string();
      in.image_size = static_cast<long long>(fs::file_size(path, ec));
    } else {
      out_ << "Image file not found.\n";
    }
  }
  if (!ask("Short Description", in.description)) return false;
  if (!ask("Full Description", in.detail)) return false;
  return true;
}

void DishManagementScreen::copyImage(const std::string& source, const std::string& relative_target) {
  if (source.empty() || relative_target.empty()) return;
  try {
    const fs::path target = fs::path(static_dir_) / relative_target;
    fs::create_directories(target.parent_path());
    fs::copy_file(source, target, fs::copy_options::overwrite_existing);
  } catch (const fs::filesystem_error&) {
    out_ << "The dish was saved, but the image file could not be copied.\n";
  }
}

void DishManagementScreen::addFlow() {
  DishInput in;
  in.status = dish_status::kAvailable;
  in.discount = "0";
  std::string image_path;
  while (true) {
    out_ << "\n--- Add New Dish ---\n";
    if (!askForm(in, true, image_path)) { out_ << "Cancelled.\n"; return; }
    try {
      const Product p = service_.addDish(in);
      copyImage(image_path, p.image);
      out_ << "Dish added successfully.\n";
      return;
    } catch (const ValidationError& e) {
      for (const auto& err : e.errors()) out_ << "Error: " << err << "\n";
      out_ << "Press Enter to correct the form, or type 'cancel': ";
      std::string answer;
      if (!std::getline(in_, answer) || toLowerAscii(trim(answer)) == "cancel") { out_ << "Cancelled.\n"; return; }
    } catch (const std::exception& e) {  // SaveError, DataAccessError
      out_ << e.what() << "\n";
      return;
    }
  }
}

void DishManagementScreen::editFlow(const std::string& code) {
  Product existing;
  try {
    existing = service_.getDish(code);
  } catch (const std::exception& e) {  // DishNotFoundError, DataAccessError
    out_ << e.what() << "\n";
    return;
  }
  DishInput in;
  in.code = existing.code;
  in.name = existing.name;
  in.category_id = std::to_string(existing.category_id);
  in.price = std::to_string(existing.price);
  in.discount = std::to_string(existing.discount);
  in.status = existing.status;
  in.description = existing.description;
  in.detail = existing.detail;
  std::string image_path;
  while (true) {
    out_ << "\n--- Update Dish " << existing.code << " ---\n";
    if (!askForm(in, false, image_path)) { out_ << "Cancelled.\n"; return; }
    try {
      const Product p = service_.updateDish(existing.code, in);
      copyImage(image_path, p.image);
      out_ << "Dish updated successfully.\n";
      return;
    } catch (const ValidationError& e) {
      for (const auto& err : e.errors()) out_ << "Error: " << err << "\n";
      out_ << "Press Enter to correct the form, or type 'cancel': ";
      std::string answer;
      if (!std::getline(in_, answer) || toLowerAscii(trim(answer)) == "cancel") { out_ << "Cancelled.\n"; return; }
    } catch (const std::exception& e) {
      out_ << e.what() << "\n";
      return;
    }
  }
}

void DishManagementScreen::deleteFlow(const std::string& code) {
  Product dish;
  try {
    dish = service_.getDish(code);
  } catch (const std::exception& e) {
    out_ << e.what() << "\n";
    return;
  }
  out_ << "Delete dish " << dish.code << " - " << dish.name
       << "? If it already appears in orders it will be set to Discontinued instead. (y/N): ";
  std::string answer;
  if (!std::getline(in_, answer) || toLowerAscii(trim(answer)) != "y") { out_ << "Cancelled.\n"; return; }
  try {
    const std::string result = service_.deleteDish(dish.code);
    if (result == "DELETED") out_ << "Dish deleted successfully.\n";
    else out_ << "This dish already appears in orders, so it has been set to Discontinued instead.\n";
  } catch (const std::exception& e) {
    out_ << e.what() << "\n";
  }
}

void DishManagementScreen::run(const Auth& auth) {
  if (!auth.isLoggedIn()) { out_ << "Please log in as an administrator to manage dishes.\n"; return; }
  if (!auth.canAccessAdmin()) { out_ << "Access denied. Only administrators can manage dishes.\n"; return; }

  render();
  std::string line, cmd, arg;
  while (true) {
    out_ << "admin> ";
    if (!std::getline(in_, line)) return;
    splitCommand(line, cmd, arg);
    int number = 0;
    if (cmd == "q") return;
    else if (cmd == "s") { keyword_ = arg; page_ = 1; }
    else if (cmd == "c") {
      if (toLowerAscii(arg) == "all") category_id_.reset();
      else if (parsePositiveInt(arg, number)) category_id_ = number;
      else { out_ << "Please enter a category number or 'all'.\n"; continue; }
      page_ = 1;
    }
    else if (cmd == "t") {
      const std::string s = parseStatusChoice(arg);
      if (toLowerAscii(arg) == "all") status_.clear();
      else if (dish_status::isValid(s)) status_ = s;
      else { out_ << "Status must be all, available, sold_out or discontinued.\n"; continue; }
      page_ = 1;
    }
    else if (cmd == "n") ++page_;
    else if (cmd == "p") --page_;
    else if (cmd == "add") addFlow();
    else if (cmd == "edit") editFlow(arg);
    else if (cmd == "del") deleteFlow(arg);
    else if (cmd == "r") {}
    else { out_ << "Unknown command.\n"; continue; }
    render();
  }
}
