#pragma once
#include <iostream>
#include <optional>
#include <string>

#include "Auth.h"  // lớp Auth của TV3 (session + phân quyền)
#include "services/MenuService.h"

// Màn hình quản trị món (Manage Dishes: Figure 5-8). Chỉ ADMIN được vào.
class DishManagementScreen {
 public:
  // static_dir: thư mục gốc để lưu ảnh món (ảnh lưu tại <static_dir>/uploads/dishes/<mã>.<jpg|png>)
  DishManagementScreen(MenuService& service, std::istream& in, std::ostream& out,
                       std::string static_dir = "static")
      : service_(service), in_(in), out_(out), static_dir_(std::move(static_dir)) {}

  void run(const Auth& auth);  // chỉ admin đang đăng nhập mới vào được

 private:
  void render();
  void addFlow();
  void editFlow(const std::string& code);
  void deleteFlow(const std::string& code);
  bool askForm(DishInput& input, bool is_new, std::string& image_path);
  bool ask(const std::string& label, std::string& value);
  void copyImage(const std::string& source, const std::string& relative_target);

  MenuService& service_;
  std::istream& in_;
  std::ostream& out_;
  std::string static_dir_;

  std::string keyword_;
  std::optional<int> category_id_;
  std::string status_;  // rỗng = tất cả
  int page_ = 1;
};
