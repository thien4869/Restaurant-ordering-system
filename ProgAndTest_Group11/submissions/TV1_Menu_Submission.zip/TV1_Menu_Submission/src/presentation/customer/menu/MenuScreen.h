#pragma once
#include <functional>
#include <iostream>
#include <optional>
#include <string>

#include "services/MenuService.h"

// Màn hình khách: Browse Menu / Search Dish / View Dish Details (Figure 3, 4).
// Chỉ hiển thị và nhận dữ liệu nhập; mọi nghiệp vụ nằm ở MenuService.
class MenuScreen {
 public:
  // add_to_cart do TV2 (Manage Cart) cung cấp; để trống thì báo "cart chưa sẵn sàng".
  using AddToCartHandler = std::function<void(const std::string& code, int qty)>;

  MenuScreen(MenuService& service, std::istream& in, std::ostream& out,
             AddToCartHandler add_to_cart = nullptr)
      : service_(service), in_(in), out_(out), add_to_cart_(std::move(add_to_cart)) {}

  void run();

 private:
  void render();
  void printDishLine(const Product& dish);
  void showDetail(const std::string& code);

  MenuService& service_;
  std::istream& in_;
  std::ostream& out_;
  AddToCartHandler add_to_cart_;

  std::optional<int> category_id_;
  std::optional<std::string> keyword_;  // có giá trị = đang ở chế độ tìm kiếm
  SortKey sort_ = SortKey::NEWEST;
  int page_ = 1;
};
