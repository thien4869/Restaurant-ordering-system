#include "presentation/customer/menu/MenuScreen.h"

#include "common/FormatHelper.h"
#include "presentation/ConsoleHelper.h"

namespace {

std::string sortLabel(SortKey key) {
  switch (key) {
    case SortKey::PRICE_ASC: return "Price (low to high)";
    case SortKey::PRICE_DESC: return "Price (high to low)";
    case SortKey::DISCOUNT_ASC: return "Discount (low to high)";
    case SortKey::DISCOUNT_DESC: return "Discount (high to low)";
    case SortKey::ORDERS_ASC: return "Orders (low to high)";
    case SortKey::ORDERS_DESC: return "Orders (high to low)";
    case SortKey::NEWEST: break;
  }
  return "Newest";
}

std::string priceText(const Product& d) {
  std::string text = formatVnd(d.final_price);
  if (d.discount > 0) text += " (was " + formatVnd(d.price) + ", " + std::to_string(d.discount) + "% OFF)";
  return text;
}

}  // namespace

void MenuScreen::printDishLine(const Product& d) {
  out_ << " " << d.code << " | " << d.name << " | " << d.category_name << " | "
       << dish_status::label(d.status) << " | " << priceText(d) << "\n";
}

void MenuScreen::render() {
  out_ << "\n==============================\n NutriBite - Our Menu\n==============================\n";
  try {
    DishPage result = keyword_ ? service_.searchDishes(*keyword_, sort_, page_)
                               : service_.browseMenu(category_id_, sort_, page_);
    page_ = result.page;
    out_ << "Categories: " << (!keyword_ && !category_id_ ? "[All Dishes]" : "All Dishes");
    for (const auto& c : result.categories)
      out_ << "  " << (!keyword_ && category_id_ == c.id ? "[" + c.name + "]" : c.name) << " (" << c.id << ")";
    out_ << "\n";
    if (keyword_) out_ << "Search: \"" << *keyword_ << "\"\n";
    out_ << "Sort by: " << sortLabel(sort_) << "\n------------------------------\n";
    for (const auto& d : result.items) printDishLine(d);
    if (!result.message.empty()) out_ << result.message << "\n";
    out_ << "------------------------------\nPage " << result.page << "/" << result.total_pages << "\n";
  } catch (const DataAccessError& e) {
    out_ << e.what() << "\nType 'r' to try again.\n";
  }
  out_ << "Commands: a=all dishes | c <id>=category | s <keyword>=search | "
          "o <newest|price|price_desc|discount_asc|discount_desc|orders_asc|orders_desc>=sort | n/p=next/prev page | "
          "g <page> | d <code>=details | r=reload | q=back\n";
}

void MenuScreen::showDetail(const std::string& code) {
  try {
    const Product d = service_.getDetail(code);
    out_ << "\n< Back to menu\n" << d.name << "\n"
         << "Dish ID: #" << d.code << " | Category: " << d.category_name
         << " | Status: " << dish_status::label(d.status) << "\n"
         << "Price: " << priceText(d) << "\n"
         << "Views: " << d.views << " | Ordered: " << d.sold << "\n"
         << "Short description: " << d.description << "\n"
         << "Full description: " << d.detail << "\n";
    out_ << (d.status == dish_status::kSoldOut ? "Sold Out" : "Commands: a [qty]=Add to Cart") << " | b=Back\n";

    std::string line, cmd, arg;
    while (true) {
      out_ << "detail> ";
      if (!std::getline(in_, line)) return;
      splitCommand(line, cmd, arg);
      if (cmd.empty() || cmd == "b") return;
      if (cmd != "a") { out_ << "Unknown command.\n"; continue; }
      if (d.status == dish_status::kSoldOut) { out_ << "This dish is sold out.\n"; continue; }
      int qty = 1;
      if (!arg.empty() && !parsePositiveInt(arg, qty)) {
        out_ << "Quantity must be a positive whole number.\n";
        continue;
      }
      if (!add_to_cart_) out_ << "The cart is not available yet.\n";
      else { add_to_cart_(d.code, qty); out_ << "Added to cart.\n"; }
    }
  } catch (const DishNotFoundError& e) {
    out_ << e.what() << "\n";
  } catch (const DataAccessError& e) {
    out_ << e.what() << "\n";
  }
}

void MenuScreen::run() {
  render();
  std::string line, cmd, arg;
  while (true) {
    out_ << "menu> ";
    if (!std::getline(in_, line)) return;
    splitCommand(line, cmd, arg);
    int number = 0;
    if (cmd == "q") return;
    else if (cmd == "a") { category_id_.reset(); keyword_.reset(); page_ = 1; }
    else if (cmd == "c") {
      if (!parsePositiveInt(arg, number)) { out_ << "Please enter a valid category number.\n"; continue; }
      category_id_ = number; keyword_.reset(); page_ = 1;
    }
    else if (cmd == "s") { keyword_ = arg; category_id_.reset(); page_ = 1; }  // "s" trống -> "Please enter a keyword."
    else if (cmd == "o") { sort_ = parseSortKey(arg); page_ = 1; }
    else if (cmd == "n") ++page_;
    else if (cmd == "p") --page_;
    else if (cmd == "g") {
      if (!parsePositiveInt(arg, number)) { out_ << "Please enter a valid page number.\n"; continue; }
      page_ = number;
    }
    else if (cmd == "d") { showDetail(arg); }
    else if (cmd == "r") {}
    else { out_ << "Unknown command.\n"; continue; }
    render();
  }
}
