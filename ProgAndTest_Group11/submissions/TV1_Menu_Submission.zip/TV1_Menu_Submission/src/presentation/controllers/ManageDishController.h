#pragma once
#include <optional>
#include <string>
#include "integration/Tv3AuthRoleAdapter.h"
#include "services/MenuService.h"

// API boundary for Figma Admin Menu / Add / Edit / Delete screens.
// Auth is supplied by TV3; no login/session implementation is duplicated in TV1.
class ManageDishController {
 public:
  explicit ManageDishController(MenuService& service) : service_(service) {}

  template <typename AuthType>
  DishPage list(const std::string& keyword, std::optional<int> category_id,
                const std::string& status, int page, const AuthType& auth) {
    tv1::integration::requireAdmin(auth);
    return service_.manageDishes(keyword, category_id, status, page);
  }

  template <typename AuthType>
  Product add(const DishInput& input, const AuthType& auth) {
    tv1::integration::requireAdmin(auth);
    return service_.addDish(input);
  }

  template <typename AuthType>
  Product update(const std::string& code, const DishInput& input, const AuthType& auth) {
    tv1::integration::requireAdmin(auth);
    return service_.updateDish(code, input);
  }

  template <typename AuthType>
  std::string remove(const std::string& code, const AuthType& auth) {
    tv1::integration::requireAdmin(auth);
    return service_.deleteDish(code);
  }

 private:
  MenuService& service_;
};
