#pragma once
#include <optional>
#include "services/MenuService.h"

// Called by the application's route/API handler for the Figma Browse Menu screen.
class BrowseMenuController {
 public:
  explicit BrowseMenuController(MenuService& service) : service_(service) {}
  DishPage execute(std::optional<int> category_id, SortKey sort = SortKey::NEWEST, int page = 1);
 private:
  MenuService& service_;
};
