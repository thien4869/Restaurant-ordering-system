#include "presentation/controllers/BrowseMenuController.h"
DishPage BrowseMenuController::execute(std::optional<int> category_id, SortKey sort, int page) {
  return service_.browseMenu(category_id, sort, page);
}
