#include "presentation/controllers/DishDetailsController.h"
Product DishDetailsController::execute(const std::string& dish_code) {
  return service_.getDetail(dish_code);
}
