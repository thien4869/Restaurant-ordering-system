#include "presentation/controllers/SearchDishController.h"
DishPage SearchDishController::execute(const std::string& keyword, SortKey sort, int page) {
  return service_.searchDishes(keyword, sort, page);
}
