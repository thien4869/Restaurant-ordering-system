#pragma once
#include <string>
#include "services/MenuService.h"

// Opening a detail screen must call execute exactly once so views increases exactly once.
class DishDetailsController {
 public:
  explicit DishDetailsController(MenuService& service) : service_(service) {}
  Product execute(const std::string& dish_code);
 private:
  MenuService& service_;
};
