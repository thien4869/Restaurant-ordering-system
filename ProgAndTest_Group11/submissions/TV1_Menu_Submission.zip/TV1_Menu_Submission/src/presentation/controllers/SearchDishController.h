#pragma once
#include <string>
#include "services/MenuService.h"

// Called by the application's route/API handler for the Figma Search screen.
class SearchDishController {
 public:
  explicit SearchDishController(MenuService& service) : service_(service) {}
  DishPage execute(const std::string& keyword, SortKey sort = SortKey::NEWEST, int page = 1);
 private:
  MenuService& service_;
};
