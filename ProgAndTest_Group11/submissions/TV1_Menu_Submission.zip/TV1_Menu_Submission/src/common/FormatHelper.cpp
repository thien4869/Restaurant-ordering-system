#include "common/FormatHelper.h"

std::string formatVnd(long long amount) {
  const bool negative = amount < 0;
  const std::string digits = std::to_string(negative ? -amount : amount);
  std::string out;
  for (std::size_t i = 0; i < digits.size(); ++i) {
    if (i != 0 && (digits.size() - i) % 3 == 0) out.push_back('.');
    out.push_back(digits[i]);
  }
  return (negative ? "-" : "") + out + " VND";
}
