#include "common/PriceHelper.h"

long long PriceHelper::priceAfterDiscount(long long price, int discount) {
  if (discount < 0) discount = 0;
  if (discount > 100) discount = 100;
  return (price * (100 - discount) + 50) / 100;
}
