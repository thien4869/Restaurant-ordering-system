#pragma once
#include <string>

// 61200 -> "61.200 VND"
std::string formatVnd(long long amount);
