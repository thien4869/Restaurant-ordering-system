#pragma once
#include <cstddef>
#include <string>

// Chữ thường + bỏ dấu tiếng Việt (đ -> d) + gộp khoảng trắng. Dùng cho Search Dish:
// "Phở Bò" và "pho bo" cho cùng kết quả. Nhận chuỗi UTF-8 (cả dạng dựng sẵn lẫn dạng tổ hợp).
std::string normalizeText(const std::string& text);

std::string trim(const std::string& text);
std::string toUpperAscii(std::string text);
std::string toLowerAscii(std::string text);
std::size_t utf8Length(const std::string& text);  // số ký tự (không phải số byte)
