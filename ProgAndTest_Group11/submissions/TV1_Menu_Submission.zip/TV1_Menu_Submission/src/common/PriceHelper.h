#pragma once
// TẠM THỜI - file này do TV2 phụ trách (src/common/PriceHelper, hàm tính giá sau giảm DÙNG CHUNG).
// Nếu TV2 đã đẩy bản chính thức lên main thì KHÔNG chép file này; chỉ cần sửa 1 dòng
// trong MenuService.cpp (hàm finalPrice) cho khớp tên hàm của TV2.
struct PriceHelper {
  // Giá sau giảm = price x (1 - discount/100); VND nguyên, làm tròn nửa lên. Không dùng số thực.
  static long long priceAfterDiscount(long long price, int discount);
};
