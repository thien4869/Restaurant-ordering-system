#include "common/TextHelper.h"

#include <cctype>
#include <unordered_map>
#include <vector>

namespace {

std::vector<char32_t> decodeUtf8(const std::string& s) {
  std::vector<char32_t> out;
  for (std::size_t i = 0; i < s.size();) {
    const unsigned char c = static_cast<unsigned char>(s[i]);
    std::size_t len = 1;
    char32_t cp = c;
    if (c >= 0xF0 && c < 0xF8) { len = 4; cp = c & 0x07; }
    else if (c >= 0xE0 && c < 0xF0) { len = 3; cp = c & 0x0F; }
    else if (c >= 0xC0 && c < 0xE0) { len = 2; cp = c & 0x1F; }
    bool ok = (len == 1) || (i + len <= s.size());
    if (ok) {
      for (std::size_t k = 1; k < len; ++k) {
        const unsigned char b = static_cast<unsigned char>(s[i + k]);
        if ((b & 0xC0) != 0x80) { ok = false; break; }
        cp = (cp << 6) | (b & 0x3F);
      }
    }
    if (!ok) { len = 1; cp = c; }  // byte lạc: giữ nguyên
    out.push_back(cp);
    i += len;
  }
  return out;
}

void encodeUtf8(char32_t cp, std::string& out) {
  if (cp < 0x80) {
    out.push_back(static_cast<char>(cp));
  } else if (cp < 0x800) {
    out.push_back(static_cast<char>(0xC0 | (cp >> 6)));
    out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
  } else if (cp < 0x10000) {
    out.push_back(static_cast<char>(0xE0 | (cp >> 12)));
    out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3F)));
    out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
  } else {
    out.push_back(static_cast<char>(0xF0 | (cp >> 18)));
    out.push_back(static_cast<char>(0x80 | ((cp >> 12) & 0x3F)));
    out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3F)));
    out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
  }
}

// Mọi chữ cái có dấu (hoa + thường) -> chữ Latin thường không dấu.
const std::unordered_map<char32_t, char>& accentTable() {
  static const std::unordered_map<char32_t, char> table = [] {
    std::unordered_map<char32_t, char> t;
    const struct { char base; const char* letters; } groups[] = {
        {'a', "àáảãạăằắẳẵặâầấẩẫậÀÁẢÃẠĂẰẮẲẴẶÂẦẤẨẪẬ"},
        {'e', "èéẻẽẹêềếểễệÈÉẺẼẸÊỀẾỂỄỆ"},
        {'i', "ìíỉĩịÌÍỈĨỊ"},
        {'o', "òóỏõọôồốổỗộơờớởỡợÒÓỎÕỌÔỒỐỔỖỘƠỜỚỞỠỢ"},
        {'u', "ùúủũụưừứửữựÙÚỦŨỤƯỪỨỬỮỰ"},
        {'y', "ỳýỷỹỵỲÝỶỸỴ"},
        {'d', "đĐ"},
    };
    for (const auto& g : groups)
      for (char32_t cp : decodeUtf8(g.letters)) t[cp] = g.base;
    return t;
  }();
  return table;
}

}  // namespace

std::string normalizeText(const std::string& text) {
  const auto& table = accentTable();
  std::string out;
  bool pending_space = false;
  for (char32_t cp : decodeUtf8(text)) {
    if (cp >= 0x0300 && cp <= 0x036F) continue;  // dấu rời (chuỗi dạng tổ hợp)
    if (cp == ' ' || cp == '\t' || cp == '\n' || cp == '\r' || cp == 0x00A0) {
      pending_space = !out.empty();
      continue;
    }
    if (pending_space) { out.push_back(' '); pending_space = false; }
    if (cp < 0x80) {
      out.push_back(static_cast<char>(std::tolower(static_cast<unsigned char>(cp))));
    } else {
      auto it = table.find(cp);
      if (it != table.end()) out.push_back(it->second);
      else encodeUtf8(cp, out);
    }
  }
  return out;
}

std::string trim(const std::string& text) {
  const char* ws = " \t\r\n";
  const auto first = text.find_first_not_of(ws);
  if (first == std::string::npos) return "";
  const auto last = text.find_last_not_of(ws);
  return text.substr(first, last - first + 1);
}

std::string toUpperAscii(std::string text) {
  for (char& c : text) c = static_cast<char>(std::toupper(static_cast<unsigned char>(c)));
  return text;
}

std::string toLowerAscii(std::string text) {
  for (char& c : text) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
  return text;
}

std::size_t utf8Length(const std::string& text) {
  std::size_t n = 0;
  for (unsigned char c : text)
    if ((c & 0xC0) != 0x80) ++n;
  return n;
}
