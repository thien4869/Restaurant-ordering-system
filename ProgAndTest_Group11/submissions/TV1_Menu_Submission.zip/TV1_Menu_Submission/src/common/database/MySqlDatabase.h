#pragma once

#include "common/database/IDatabase.h"
#include <mysql/mysql.h>
#include <string>

// MySQL implementation of IDatabase. SQL remains in MenuRepository; all values
// are bound through prepared statements (placeholder '?').
class MySqlDatabase final : public IDatabase {
 public:
  MySqlDatabase(const std::string& host, const std::string& user,
                const std::string& password, const std::string& database,
                unsigned int port = 3306);
  ~MySqlDatabase() override;

  MySqlDatabase(const MySqlDatabase&) = delete;
  MySqlDatabase& operator=(const MySqlDatabase&) = delete;

  std::vector<DbRow> query(const std::string& sql,
                           const std::vector<DbValue>& params = {}) override;
  void execute(const std::string& sql,
               const std::vector<DbValue>& params = {}) override;
  void begin() override;
  void commit() override;
  void rollback() override;

 private:
  MYSQL* connection_ = nullptr;
};
