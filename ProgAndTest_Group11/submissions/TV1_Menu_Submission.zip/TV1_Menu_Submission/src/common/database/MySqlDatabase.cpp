#include "common/database/MySqlDatabase.h"

#include <algorithm>
#include <cstring>
#include <memory>
#include <stdexcept>
#include <utility>

namespace {

struct StatementCloser {
  void operator()(MYSQL_STMT* statement) const {
    if (statement) mysql_stmt_close(statement);
  }
};
using StatementPtr = std::unique_ptr<MYSQL_STMT, StatementCloser>;

StatementPtr prepare(MYSQL* connection, const std::string& sql) {
  StatementPtr statement(mysql_stmt_init(connection));
  if (!statement) throw std::runtime_error("Unable to initialize MySQL statement.");
  if (mysql_stmt_prepare(statement.get(), sql.c_str(), static_cast<unsigned long>(sql.size())) != 0) {
    throw std::runtime_error(std::string("MySQL prepare failed: ") + mysql_stmt_error(statement.get()));
  }
  return statement;
}

void bindParameters(MYSQL_STMT* statement, const std::vector<DbValue>& params) {
  if (params.empty()) return;
  std::vector<MYSQL_BIND> bindings(params.size());
  std::vector<unsigned long> lengths(params.size(), 0);
  std::vector<my_bool> nullFlags(params.size(), 0);

  for (std::size_t i = 0; i < params.size(); ++i) {
    MYSQL_BIND& bind = bindings[i];
    std::memset(&bind, 0, sizeof(bind));
    if (std::holds_alternative<std::nullptr_t>(params[i])) {
      bind.buffer_type = MYSQL_TYPE_NULL;
      nullFlags[i] = 1;
      bind.is_null = &nullFlags[i];
    } else if (std::holds_alternative<long long>(params[i])) {
      bind.buffer_type = MYSQL_TYPE_LONGLONG;
      bind.buffer = const_cast<long long*>(&std::get<long long>(params[i]));
      bind.buffer_length = sizeof(long long);
    } else {
      const std::string& value = std::get<std::string>(params[i]);
      bind.buffer_type = MYSQL_TYPE_STRING;
      bind.buffer = const_cast<char*>(value.data());
      lengths[i] = static_cast<unsigned long>(value.size());
      bind.buffer_length = lengths[i];
      bind.length = &lengths[i];
    }
  }
  if (mysql_stmt_bind_param(statement, bindings.data()) != 0) {
    throw std::runtime_error(std::string("MySQL parameter binding failed: ") + mysql_stmt_error(statement));
  }
}

void checkExecute(MYSQL_STMT* statement) {
  if (mysql_stmt_execute(statement) != 0) {
    throw std::runtime_error(std::string("MySQL execute failed: ") + mysql_stmt_error(statement));
  }
}

} // namespace

MySqlDatabase::MySqlDatabase(const std::string& host, const std::string& user,
                             const std::string& password, const std::string& database,
                             unsigned int port) {
  connection_ = mysql_init(nullptr);
  if (!connection_) throw std::runtime_error("Unable to initialize MySQL client.");
  if (!mysql_real_connect(connection_, host.c_str(), user.c_str(), password.c_str(),
                          database.c_str(), port, nullptr, 0)) {
    const std::string message = mysql_error(connection_);
    mysql_close(connection_);
    connection_ = nullptr;
    throw std::runtime_error("MySQL connection failed: " + message);
  }
  if (mysql_set_character_set(connection_, "utf8mb4") != 0) {
    const std::string message = mysql_error(connection_);
    mysql_close(connection_);
    connection_ = nullptr;
    throw std::runtime_error("Unable to set MySQL connection to utf8mb4: " + message);
  }
}

MySqlDatabase::~MySqlDatabase() {
  if (connection_) mysql_close(connection_);
}

std::vector<DbRow> MySqlDatabase::query(const std::string& sql, const std::vector<DbValue>& params) {
  StatementPtr statement = prepare(connection_, sql);
  bindParameters(statement.get(), params);
  checkExecute(statement.get());

  if (mysql_stmt_store_result(statement.get()) != 0) {
    throw std::runtime_error(std::string("MySQL result buffering failed: ") + mysql_stmt_error(statement.get()));
  }
  MYSQL_RES* metadata = mysql_stmt_result_metadata(statement.get());
  if (!metadata) {
    if (mysql_stmt_field_count(statement.get()) == 0) return {};
    throw std::runtime_error(std::string("MySQL metadata failed: ") + mysql_stmt_error(statement.get()));
  }
  std::unique_ptr<MYSQL_RES, decltype(&mysql_free_result)> meta(metadata, mysql_free_result);
  const unsigned int columnCount = mysql_num_fields(metadata);
  MYSQL_FIELD* fields = mysql_fetch_fields(metadata);

  std::vector<std::vector<char>> buffers(columnCount);
  std::vector<unsigned long> lengths(columnCount, 0);
  std::vector<my_bool> nullFlags(columnCount, 0);
  std::vector<MYSQL_BIND> results(columnCount);
  for (unsigned int i = 0; i < columnCount; ++i) {
    // max_length is available after mysql_stmt_store_result(). The fetch-column
    // fallback below also handles long text values if the driver reports a shorter size.
    const unsigned long capacity = std::max<unsigned long>(fields[i].max_length + 1, 2);
    buffers[i].resize(capacity);
    MYSQL_BIND& bind = results[i];
    std::memset(&bind, 0, sizeof(bind));
    bind.buffer_type = MYSQL_TYPE_STRING;
    bind.buffer = buffers[i].data();
    bind.buffer_length = static_cast<unsigned long>(buffers[i].size());
    bind.length = &lengths[i];
    bind.is_null = &nullFlags[i];
  }

  if (mysql_stmt_bind_result(statement.get(), results.data()) != 0) {
    throw std::runtime_error(std::string("MySQL result binding failed: ") + mysql_stmt_error(statement.get()));
  }

  std::vector<DbRow> rows;
  while (true) {
    const int fetchStatus = mysql_stmt_fetch(statement.get());
    if (fetchStatus == MYSQL_NO_DATA) break;
    if (fetchStatus != 0 && fetchStatus != MYSQL_DATA_TRUNCATED) {
      throw std::runtime_error(std::string("MySQL fetch failed: ") + mysql_stmt_error(statement.get()));
    }

    DbRow row;
    row.reserve(columnCount);
    for (unsigned int i = 0; i < columnCount; ++i) {
      if (nullFlags[i]) {
        row.emplace_back();
        continue;
      }
      if (lengths[i] > buffers[i].size()) {
        buffers[i].resize(lengths[i]);
        MYSQL_BIND column{};
        column.buffer_type = MYSQL_TYPE_STRING;
        column.buffer = buffers[i].data();
        column.buffer_length = lengths[i];
        column.length = &lengths[i];
        if (mysql_stmt_fetch_column(statement.get(), &column, i, 0) != 0) {
          throw std::runtime_error(std::string("MySQL column fetch failed: ") + mysql_stmt_error(statement.get()));
        }
        // Keep the result binding pointed at the resized vector for the next row.
        results[i].buffer = buffers[i].data();
        results[i].buffer_length = static_cast<unsigned long>(buffers[i].size());
      }
      row.emplace_back(buffers[i].data(), lengths[i]);
    }
    rows.push_back(std::move(row));
  }
  return rows;
}

void MySqlDatabase::execute(const std::string& sql, const std::vector<DbValue>& params) {
  StatementPtr statement = prepare(connection_, sql);
  bindParameters(statement.get(), params);
  checkExecute(statement.get());
}

void MySqlDatabase::begin() {
  if (mysql_autocommit(connection_, 0) != 0 || mysql_query(connection_, "START TRANSACTION") != 0) {
    throw std::runtime_error(std::string("Unable to start MySQL transaction: ") + mysql_error(connection_));
  }
}

void MySqlDatabase::commit() {
  if (mysql_commit(connection_) != 0) {
    const std::string message = mysql_error(connection_);
    mysql_rollback(connection_);
    mysql_autocommit(connection_, 1);
    throw std::runtime_error("MySQL commit failed: " + message);
  }
  if (mysql_autocommit(connection_, 1) != 0) {
    throw std::runtime_error(std::string("Unable to restore MySQL autocommit: ") + mysql_error(connection_));
  }
}

void MySqlDatabase::rollback() {
  const int rollbackStatus = mysql_rollback(connection_);
  const int autocommitStatus = mysql_autocommit(connection_, 1);
  if (rollbackStatus != 0 || autocommitStatus != 0) {
    throw std::runtime_error(std::string("MySQL rollback failed: ") + mysql_error(connection_));
  }
}
