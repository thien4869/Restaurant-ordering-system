#include "common/database/SqliteDatabase.h"

#include <sqlite3.h>

#include <stdexcept>

namespace {

class Statement {
 public:
  Statement(sqlite3* db, const std::string& sql, const std::vector<DbValue>& params) : db_(db) {
    if (sqlite3_prepare_v2(db, sql.c_str(), -1, &stmt_, nullptr) != SQLITE_OK)
      throw std::runtime_error(std::string("SQL prepare failed: ") + sqlite3_errmsg(db));
    for (std::size_t i = 0; i < params.size(); ++i) {
      const int index = static_cast<int>(i) + 1;
      switch (params[i].index()) {
        case 0: sqlite3_bind_null(stmt_, index); break;
        case 1: sqlite3_bind_int64(stmt_, index, std::get<long long>(params[i])); break;
        default: {
          const std::string& s = std::get<std::string>(params[i]);
          sqlite3_bind_text(stmt_, index, s.c_str(), static_cast<int>(s.size()), SQLITE_TRANSIENT);
        }
      }
    }
  }
  ~Statement() { sqlite3_finalize(stmt_); }
  Statement(const Statement&) = delete;
  Statement& operator=(const Statement&) = delete;

  bool step() {
    const int rc = sqlite3_step(stmt_);
    if (rc == SQLITE_ROW) return true;
    if (rc == SQLITE_DONE) return false;
    throw std::runtime_error(std::string("SQL step failed: ") + sqlite3_errmsg(db_));
  }
  DbRow row() {
    DbRow r;
    const int n = sqlite3_column_count(stmt_);
    for (int i = 0; i < n; ++i) {
      const unsigned char* p = sqlite3_column_text(stmt_, i);
      r.push_back(p ? reinterpret_cast<const char*>(p) : "");
    }
    return r;
  }

 private:
  sqlite3* db_;
  sqlite3_stmt* stmt_ = nullptr;
};

}  // namespace

SqliteDatabase::SqliteDatabase(const std::string& path) {
  if (sqlite3_open(path.c_str(), &db_) != SQLITE_OK) {
    const std::string message = db_ ? sqlite3_errmsg(db_) : "cannot open database";
    sqlite3_close(db_);
    db_ = nullptr;
    throw std::runtime_error("Cannot open database: " + message);
  }
  runScript("PRAGMA foreign_keys = ON");
}

SqliteDatabase::~SqliteDatabase() { sqlite3_close(db_); }

std::vector<DbRow> SqliteDatabase::query(const std::string& sql, const std::vector<DbValue>& params) {
  Statement s(db_, sql, params);
  std::vector<DbRow> rows;
  while (s.step()) rows.push_back(s.row());
  return rows;
}

void SqliteDatabase::execute(const std::string& sql, const std::vector<DbValue>& params) {
  Statement s(db_, sql, params);
  while (s.step()) {}
}

void SqliteDatabase::begin() { runScript("BEGIN"); }
void SqliteDatabase::commit() { runScript("COMMIT"); }
void SqliteDatabase::rollback() { sqlite3_exec(db_, "ROLLBACK", nullptr, nullptr, nullptr); }

namespace {
void replaceAll(std::string& text, const std::string& from, const std::string& to) {
  for (std::size_t pos = text.find(from); pos != std::string::npos; pos = text.find(from, pos + to.size()))
    text.replace(pos, from.size(), to);
}
}  // namespace

void SqliteDatabase::runMySqlScript(std::string sql) {
  replaceAll(sql, "ENGINE=InnoDB DEFAULT CHARSET=utf8mb4", "");
  replaceAll(sql, "INT AUTO_INCREMENT PRIMARY KEY", "INTEGER PRIMARY KEY AUTOINCREMENT");
  replaceAll(sql, "SET NAMES utf8mb4;", "");
  runScript(sql);
}

void SqliteDatabase::runScript(const std::string& sql) {
  char* error = nullptr;
  if (sqlite3_exec(db_, sql.c_str(), nullptr, nullptr, &error) != SQLITE_OK) {
    std::string message = error ? error : "SQL error";
    sqlite3_free(error);
    throw std::runtime_error(message);
  }
}
