#pragma once
#include <cstddef>
#include <string>
#include <variant>
#include <vector>

// Giao diện truy cập CSDL TỐI THIỂU mà MenuRepository cần.
// TV5 (src/common/database) dùng MySQL trong Docker thì viết một lớp con của IDatabase (khoảng 50 dòng,
// dùng prepared statement) rồi đưa vào MenuRepository; code của TV1 không phải sửa.
// Câu lệnh dùng placeholder '?' (MySQL prepared statement và SQLite đều hỗ trợ).
using DbValue = std::variant<std::nullptr_t, long long, std::string>;  // NULL / số nguyên / chuỗi
using DbRow = std::vector<std::string>;                                // mọi cột đọc về dạng chuỗi, NULL -> ""

class IDatabase {
 public:
  virtual ~IDatabase() = default;
  virtual std::vector<DbRow> query(const std::string& sql, const std::vector<DbValue>& params = {}) = 0;
  virtual void execute(const std::string& sql, const std::vector<DbValue>& params = {}) = 0;
  virtual void begin() = 0;
  virtual void commit() = 0;
  virtual void rollback() = 0;
};
