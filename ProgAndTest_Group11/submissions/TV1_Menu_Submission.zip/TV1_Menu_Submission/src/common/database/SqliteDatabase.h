#pragma once
#include "common/database/IDatabase.h"

struct sqlite3;

// Cài đặt IDatabase bằng SQLite: dùng để chạy thử và unit test (không cần dựng MySQL).
class SqliteDatabase : public IDatabase {
 public:
  explicit SqliteDatabase(const std::string& path);  // ":memory:" để test
  ~SqliteDatabase() override;
  SqliteDatabase(const SqliteDatabase&) = delete;
  SqliteDatabase& operator=(const SqliteDatabase&) = delete;

  std::vector<DbRow> query(const std::string& sql, const std::vector<DbValue>& params = {}) override;
  void execute(const std::string& sql, const std::vector<DbValue>& params = {}) override;
  void begin() override;
  void commit() override;
  void rollback() override;

  void runScript(const std::string& sql);  // nhiều câu lệnh một lúc
  // Chạy script viết cho MySQL (database/schema.sql, seed.sql của nhóm) trên SQLite: đổi ENGINE=..., AUTO_INCREMENT, SET NAMES.
  void runMySqlScript(std::string sql);

 private:
  sqlite3* db_ = nullptr;
};
