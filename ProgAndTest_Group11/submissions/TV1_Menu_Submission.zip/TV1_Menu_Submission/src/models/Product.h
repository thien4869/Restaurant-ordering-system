#pragma once
#include <string>

// Giá trị lưu trong CSDL (CONVENTIONS B.3)
namespace dish_status {
inline const std::string kAvailable = "AVAILABLE";
inline const std::string kSoldOut = "SOLD_OUT";
inline const std::string kDiscontinued = "DISCONTINUED";

inline bool isValid(const std::string& s) {
  return s == kAvailable || s == kSoldOut || s == kDiscontinued;
}
// Chữ hiển thị trên giao diện theo Figure 3-6 của đặc tả
inline std::string label(const std::string& s) {
  if (s == kAvailable) return "Available";
  if (s == kSoldOut) return "Sold Out";
  if (s == kDiscontinued) return "Discontinued";
  return s;
}
}  // namespace dish_status

// Product (UI gọi là "Dish"). Tiền VND là số nguyên (DECIMAL(12,0) trong CSDL), không dùng số thực.
struct Product {
  std::string code;  // "MN06"
  std::string name;
  int category_id = 0;
  std::string category_name;
  long long price = 0;
  int discount = 0;  // 0-100
  std::string status = dish_status::kAvailable;
  std::string image;  // đường dẫn tương đối, rỗng = chưa có ảnh (NULL)
  std::string description;  // mô tả ngắn (cột products.description)
  std::string detail;       // mô tả đầy đủ (cột products.detail)
  int views = 0;
  int sold = 0;  // số lượt đã bán (cột products.sold), hiển thị "Ordered"
  long long final_price = 0;  // do MenuService gán = priceAfterDiscount(price, discount)
};
