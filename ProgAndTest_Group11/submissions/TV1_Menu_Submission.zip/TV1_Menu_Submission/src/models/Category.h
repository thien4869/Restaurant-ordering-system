#pragma once
#include <string>

struct Category {
  int id = 0;
  std::string name;
};
