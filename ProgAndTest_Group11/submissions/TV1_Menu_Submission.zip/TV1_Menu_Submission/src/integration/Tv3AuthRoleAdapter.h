#pragma once

#include <stdexcept>
#include <string>

namespace tv1::integration {

// TV1 does not implement authentication. It receives the Auth object managed by TV3.
// Expected TV3 API: isLoggedIn() and canAccessAdmin().
template <typename AuthType>
bool canManageDishes(const AuthType& auth) {
    return auth.isLoggedIn() && auth.canAccessAdmin();
}

template <typename AuthType>
void requireAdmin(const AuthType& auth) {
    if (!auth.isLoggedIn()) {
        throw std::runtime_error("Please log in as an administrator to manage dishes.");
    }
    if (!auth.canAccessAdmin()) {
        throw std::runtime_error("Access denied. Only administrators can manage dishes.");
    }
}

} // namespace tv1::integration
