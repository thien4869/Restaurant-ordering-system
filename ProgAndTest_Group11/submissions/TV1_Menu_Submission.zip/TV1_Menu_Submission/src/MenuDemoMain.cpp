// Chạy thử module Thực đơn (TV1) độc lập:  menu_demo <file.db> [--role guest|customer|admin]
// Windows: chạy "chcp 65001" trước để console hiển thị đúng tiếng Việt.
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>

#include "Auth.h"
#include "User.h"
#include "common/database/SqliteDatabase.h"
#include "presentation/admin/dishes/DishManagementScreen.h"
#include "presentation/customer/menu/MenuScreen.h"
#include "repositories/MenuRepository.h"

std::string readFile(const std::string& path) {
  std::ifstream file(path);
  if (!file) throw std::runtime_error("Cannot read " + path + " (run from the repo root)");
  std::stringstream ss;
  ss << file.rdbuf();
  return ss.str();
}

int main(int argc, char** argv) {
  if (argc < 2) {
    std::cerr << "Usage: menu_demo <database.db> [--init] [--role guest|customer|admin]\n"
                 "  --init: load database/schema.sql, database/seed.sql (and seed_menu.sql if no dishes) into the new file\n";
    return 1;
  }
  std::string role = "customer";
  bool init = false;
  for (int i = 2; i < argc; ++i) {
    if (std::string(argv[i]) == "--init") init = true;
    if (std::string(argv[i]) == "--role" && i + 1 < argc) {
      role = argv[i + 1];
    }
  }
  Auth auth;  // guest: chưa đăng nhập. Bản tích hợp thật dùng AccountService::login của TV3.
  if (role == "admin" || role == "customer") {
    User user;
    user.email = role + "@example.com";
    user.role = role;
    auth.login(user);
  }
  try {
    SqliteDatabase database(argv[1]);
    if (init) {
      database.runMySqlScript(readFile("database/schema_tv5_reference.sql"));
      if (database.query("SELECT COUNT(*) FROM categories")[0][0] == "0")
        database.runScript(readFile("database/seed_categories.sql"));
      if (database.query("SELECT COUNT(*) FROM products")[0][0] == "0")
        database.runScript(readFile("database/seed_menu.sql"));
    }
    MenuRepository repository(database);
    MenuService service(repository);
    MenuScreen menu(service, std::cin, std::cout);  // Add to Cart: TV2 gắn handler vào đây
    DishManagementScreen admin(service, std::cin, std::cout);

    std::string line;
    while (true) {
      std::cout << "\n1) Menu  2) Manage dishes (admin)  0) Exit\n> ";
      if (!std::getline(std::cin, line) || line == "0") break;
      if (line == "1") menu.run();
      else if (line == "2") admin.run(auth);
    }
  } catch (const std::exception& e) {
    std::cerr << e.what() << "\n";
    return 1;
  }
  return 0;
}
