#include "repositories/MenuRepository.h"

#include <string>

namespace {

// Thứ tự cột: code, name, category_id, category name, price, discount, status, image,
// description (mô tả ngắn), detail (mô tả đầy đủ), views, sold
const char* kSelectDish =
    "SELECT p.code, p.name, p.category_id, c.name, p.price, p.discount, p.status, p.image, "
    "p.description, p.detail, p.views, p.sold "
    "FROM products p JOIN categories c ON c.category_id = p.category_id";

DbValue text(const std::string& s) { return DbValue{s}; }
DbValue integer(long long v) { return DbValue{v}; }
DbValue nullableText(const std::string& s) { return s.empty() ? DbValue{nullptr} : DbValue{s}; }

Product toProduct(const DbRow& r) {
  Product p;
  p.code = r[0];
  p.name = r[1];
  p.category_id = std::stoi(r[2]);
  p.category_name = r[3];
  p.price = std::stoll(r[4]);
  p.discount = std::stoi(r[5]);
  p.status = r[6];
  p.image = r[7];
  p.description = r[8];
  p.detail = r[9];
  p.views = std::stoi(r[10]);
  p.sold = std::stoi(r[11]);
  return p;
}

std::vector<Product> toProducts(const std::vector<DbRow>& rows) {
  std::vector<Product> out;
  for (const auto& r : rows) out.push_back(toProduct(r));
  return out;
}

}  // namespace

std::vector<Category> MenuRepository::findCategories() {
  std::vector<Category> out;
  for (const auto& r : db_.query("SELECT category_id, name FROM categories ORDER BY category_id"))
    out.push_back(Category{std::stoi(r[0]), r[1]});
  return out;
}

std::vector<Product> MenuRepository::findVisibleDishes(std::optional<int> category_id) {
  std::string sql = std::string(kSelectDish) + " WHERE p.status <> ?";
  std::vector<DbValue> params{text(dish_status::kDiscontinued)};
  if (category_id) {
    sql += " AND p.category_id = ?";
    params.push_back(integer(*category_id));
  }
  return toProducts(db_.query(sql, params));
}

std::vector<Product> MenuRepository::findAllDishes() { return toProducts(db_.query(kSelectDish)); }

std::optional<Product> MenuRepository::findDishByCode(const std::string& code) {
  auto rows = db_.query(std::string(kSelectDish) + " WHERE p.code = ?", {text(code)});
  if (rows.empty()) return std::nullopt;
  return toProduct(rows.front());
}

bool MenuRepository::codeExists(const std::string& code) {
  return !db_.query("SELECT 1 FROM products WHERE code = ?", {text(code)}).empty();
}

bool MenuRepository::isDishInOrders(const std::string& code) {
  auto rows = db_.query("SELECT COUNT(*) FROM order_details WHERE product_code = ?", {text(code)});
  return !rows.empty() && std::stoll(rows.front()[0]) > 0;
}

void MenuRepository::incrementViews(const std::string& code) {
  db_.execute("UPDATE products SET views = views + 1 WHERE code = ?", {text(code)});
}

void MenuRepository::insertDish(const Product& d) {
  db_.execute(
      "INSERT INTO products (code, name, category_id, price, discount, status, image, "
      "description, detail, views, sold) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0)",
      {text(d.code), text(d.name), integer(d.category_id), integer(d.price), integer(d.discount),
       text(d.status), nullableText(d.image), text(d.description), text(d.detail)});
}

void MenuRepository::updateDish(const Product& d) {
  db_.execute(
      "UPDATE products SET name = ?, category_id = ?, price = ?, discount = ?, status = ?, image = ?, "
      "description = ?, detail = ? WHERE code = ?",
      {text(d.name), integer(d.category_id), integer(d.price), integer(d.discount), text(d.status),
       nullableText(d.image), text(d.description), text(d.detail), text(d.code)});
}

void MenuRepository::markDiscontinued(const std::string& code) {
  db_.execute("UPDATE products SET status = ? WHERE code = ?", {text(dish_status::kDiscontinued), text(code)});
}

void MenuRepository::deleteDish(const std::string& code) {
  db_.begin();
  try {
    db_.execute("DELETE FROM cart_items WHERE product_code = ?", {text(code)});
    db_.execute("DELETE FROM products WHERE code = ?", {text(code)});
    db_.commit();
  } catch (...) {
    db_.rollback();
    throw;
  }
}
