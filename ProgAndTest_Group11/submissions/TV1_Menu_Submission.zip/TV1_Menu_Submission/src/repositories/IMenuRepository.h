#pragma once
#include <optional>
#include <string>
#include <vector>

#include "models/Category.h"
#include "models/Product.h"

// Lớp Data Access cho Thực đơn. Mọi hàm ném std::runtime_error khi lỗi CSDL.
// MenuService chỉ làm việc với interface này nên test được bằng repository giả (không cần CSDL).
class IMenuRepository {
 public:
  virtual ~IMenuRepository() = default;

  virtual std::vector<Category> findCategories() = 0;
  virtual std::vector<Product> findVisibleDishes(std::optional<int> category_id) = 0;  // trừ DISCONTINUED
  virtual std::vector<Product> findAllDishes() = 0;                                    // cho Admin
  virtual std::optional<Product> findDishByCode(const std::string& code) = 0;
  virtual bool codeExists(const std::string& code) = 0;
  virtual bool isDishInOrders(const std::string& code) = 0;

  virtual void incrementViews(const std::string& code) = 0;
  virtual void insertDish(const Product& dish) = 0;
  virtual void updateDish(const Product& dish) = 0;
  virtual void markDiscontinued(const std::string& code) = 0;
  virtual void deleteDish(const std::string& code) = 0;  // xóa dòng trong cart_items rồi mới xóa món
};
