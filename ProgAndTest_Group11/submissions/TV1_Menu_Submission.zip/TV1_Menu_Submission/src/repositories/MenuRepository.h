#pragma once
#include "common/database/IDatabase.h"
#include "repositories/IMenuRepository.h"

// Cài đặt IMenuRepository. Chỉ ở đây mới có SQL (tham số hóa bằng '?', chống SQL Injection).
// Tên bảng/cột theo ERD + CONVENTIONS B.1/B.2: categories, products, order_details, cart_items.
class MenuRepository : public IMenuRepository {
 public:
  explicit MenuRepository(IDatabase& db) : db_(db) {}

  std::vector<Category> findCategories() override;
  std::vector<Product> findVisibleDishes(std::optional<int> category_id) override;
  std::vector<Product> findAllDishes() override;
  std::optional<Product> findDishByCode(const std::string& code) override;
  bool codeExists(const std::string& code) override;
  bool isDishInOrders(const std::string& code) override;

  void incrementViews(const std::string& code) override;
  void insertDish(const Product& dish) override;
  void updateDish(const Product& dish) override;
  void markDiscontinued(const std::string& code) override;
  void deleteDish(const std::string& code) override;

 private:
  IDatabase& db_;
};
