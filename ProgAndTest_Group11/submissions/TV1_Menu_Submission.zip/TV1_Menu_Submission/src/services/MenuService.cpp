#include "services/MenuService.h"

#include <algorithm>
#include <cctype>
#include <tuple>

#include "common/PriceHelper.h"
#include "common/TextHelper.h"

namespace {

// Chỗ DUY NHẤT gọi hàm tính giá dùng chung của TV2 (src/common/PriceHelper).
long long finalPrice(long long price, int discount) { return PriceHelper::priceAfterDiscount(price, discount); }

// Lỗi đọc dữ liệu -> DataAccessError (giao diện hiện "Try again")
template <typename F>
auto loading(F&& f) -> decltype(f()) {
  try {
    return f();
  } catch (const std::exception&) {
    throw DataAccessError(msg::kLoadError);
  }
}

// Lỗi ghi dữ liệu -> SaveError; lỗi nghiệp vụ giữ nguyên
template <typename F>
auto saving(F&& f) -> decltype(f()) {
  try {
    return f();
  } catch (const ValidationError&) {
    throw;
  } catch (const DishNotFoundError&) {
    throw;
  } catch (const std::exception&) {
    throw SaveError(msg::kSaveError);
  }
}

// So sánh mã món theo kiểu "MN9" < "MN10" (phần chữ, rồi phần số)
struct CodeKey {
  std::string prefix;
  long long number;
  std::string raw;
};

CodeKey makeKey(const std::string& code) {
  std::size_t i = 0;
  while (i < code.size() && !std::isdigit(static_cast<unsigned char>(code[i]))) ++i;
  std::size_t j = i;
  while (j < code.size() && std::isdigit(static_cast<unsigned char>(code[j]))) ++j;
  long long number = 0;
  if (j > i && j - i <= 15) number = std::stoll(code.substr(i, j - i));
  return CodeKey{code.substr(0, i), number, code};
}

bool codeLess(const Product& a, const Product& b) {
  const CodeKey ka = makeKey(a.code), kb = makeKey(b.code);
  return std::tie(ka.prefix, ka.number, ka.raw) < std::tie(kb.prefix, kb.number, kb.raw);
}

void sortDishes(std::vector<Product>& dishes, SortKey key) {
  // "Mới nhất" = mã món lớn nhất trước (ERD không có cột ngày tạo); cũng là thứ tự phụ khi bằng nhau.
  std::stable_sort(dishes.begin(), dishes.end(),
                   [](const Product& a, const Product& b) { return codeLess(b, a); });
  switch (key) {
    case SortKey::PRICE_ASC:
      std::stable_sort(dishes.begin(), dishes.end(),
                       [](const Product& a, const Product& b) { return a.final_price < b.final_price; });
      break;
    case SortKey::PRICE_DESC:
      std::stable_sort(dishes.begin(), dishes.end(),
                       [](const Product& a, const Product& b) { return a.final_price > b.final_price; });
      break;
    case SortKey::DISCOUNT_ASC:
      std::stable_sort(dishes.begin(), dishes.end(),
                       [](const Product& a, const Product& b) { return a.discount < b.discount; });
      break;
    case SortKey::DISCOUNT_DESC:
      std::stable_sort(dishes.begin(), dishes.end(),
                       [](const Product& a, const Product& b) { return a.discount > b.discount; });
      break;
    case SortKey::ORDERS_ASC:
      std::stable_sort(dishes.begin(), dishes.end(),
                       [](const Product& a, const Product& b) { return a.sold < b.sold; });
      break;
    case SortKey::ORDERS_DESC:
      std::stable_sort(dishes.begin(), dishes.end(),
                       [](const Product& a, const Product& b) { return a.sold > b.sold; });
      break;
    case SortKey::NEWEST:
      break;
  }
}

void fillFinalPrice(std::vector<Product>& dishes) {
  for (auto& d : dishes) d.final_price = finalPrice(d.price, d.discount);
}

// Cắt trang: page ngoài khoảng thì kẹp về [1, total_pages]
DishPage paginate(const std::vector<Product>& dishes, int page, int page_size) {
  DishPage result;
  const int total = static_cast<int>(dishes.size());
  result.total_items = total;
  result.total_pages = std::max(1, (total + page_size - 1) / page_size);
  result.page = std::min(std::max(page, 1), result.total_pages);
  const int begin = (result.page - 1) * page_size;
  const int end = std::min(total, begin + page_size);
  for (int i = begin; i < end; ++i) result.items.push_back(dishes[i]);
  return result;
}

// ^-?\d+(\.\d+)?$
struct DecimalText {
  bool valid = false, negative = false, has_fraction = false;
  std::string integer_digits;  // đã bỏ số 0 đầu
};

DecimalText parseDecimalText(const std::string& s) {
  DecimalText r;
  std::size_t i = 0;
  if (i < s.size() && s[i] == '-') { r.negative = true; ++i; }
  std::size_t start = i;
  while (i < s.size() && std::isdigit(static_cast<unsigned char>(s[i]))) ++i;
  if (i == start) return r;
  std::string digits = s.substr(start, i - start);
  if (i < s.size()) {
    if (s[i] != '.') return r;
    ++i;
    std::size_t frac_start = i;
    while (i < s.size() && std::isdigit(static_cast<unsigned char>(s[i]))) ++i;
    if (i == frac_start || i != s.size()) return r;
    r.has_fraction = true;
  }
  const auto nz = digits.find_first_not_of('0');
  r.integer_digits = (nz == std::string::npos) ? "0" : digits.substr(nz);
  r.valid = true;
  return r;
}

bool isCodeFormatValid(const std::string& code) {
  if (code.empty() || code.size() > 20) return false;
  for (unsigned char c : code)
    if (!std::isalnum(c) && c != '-' && c != '_') return false;
  return true;
}

}  // namespace

SortKey parseSortKey(const std::string& text) {
  const std::string t = toLowerAscii(trim(text));
  if (t == "price" || t == "price_asc") return SortKey::PRICE_ASC;
  if (t == "price_desc") return SortKey::PRICE_DESC;
  if (t == "discount" || t == "discount_desc") return SortKey::DISCOUNT_DESC;
  if (t == "discount_asc") return SortKey::DISCOUNT_ASC;
  if (t == "orders" || t == "orders_desc") return SortKey::ORDERS_DESC;
  if (t == "orders_asc") return SortKey::ORDERS_ASC;
  return SortKey::NEWEST;
}

// ---------------------------------------------------------------- khách
DishPage MenuService::browseMenu(std::optional<int> category_id, SortKey sort, int page) {
  auto categories = loading([&] { return repo_.findCategories(); });
  auto dishes = loading([&] { return repo_.findVisibleDishes(category_id); });
  fillFinalPrice(dishes);
  sortDishes(dishes, sort);
  DishPage result = paginate(dishes, page, page_size_);
  result.categories = std::move(categories);
  if (dishes.empty()) result.message = msg::kEmptyCategory;
  return result;
}

DishPage MenuService::searchDishes(const std::string& keyword, SortKey sort, int page) {
  auto categories = loading([&] { return repo_.findCategories(); });
  const std::string key = normalizeText(keyword);
  if (key.empty()) {
    DishPage empty;
    empty.categories = std::move(categories);
    empty.message = msg::kEmptyKeyword;
    return empty;
  }
  auto all = loading([&] { return repo_.findVisibleDishes(std::nullopt); });
  std::vector<Product> matched;
  for (auto& d : all)
    if (normalizeText(d.name).find(key) != std::string::npos) matched.push_back(std::move(d));
  fillFinalPrice(matched);
  sortDishes(matched, sort);
  DishPage result = paginate(matched, page, page_size_);
  result.categories = std::move(categories);
  if (matched.empty()) result.message = msg::kNotFound;
  return result;
}

Product MenuService::getDetail(const std::string& code) {
  const std::string key = toUpperAscii(trim(code));
  auto dish = loading([&] { return repo_.findDishByCode(key); });
  if (!dish || dish->status == dish_status::kDiscontinued) throw DishNotFoundError(msg::kDishNotFound);
  loading([&] { repo_.incrementViews(dish->code); });
  dish->views += 1;
  dish->final_price = finalPrice(dish->price, dish->discount);
  return *dish;
}

// ---------------------------------------------------------------- admin
DishPage MenuService::manageDishes(const std::string& keyword, std::optional<int> category_id,
                                   const std::string& status, int page) {
  auto categories = loading([&] { return repo_.findCategories(); });
  auto all = loading([&] { return repo_.findAllDishes(); });

  DishSummary summary;
  summary.total = static_cast<int>(all.size());
  for (const auto& d : all) {
    if (d.status == dish_status::kAvailable) ++summary.available;
    else if (d.status == dish_status::kSoldOut) ++summary.sold_out;
    else if (d.status == dish_status::kDiscontinued) ++summary.discontinued;
  }

  const std::string key = normalizeText(keyword);
  const bool use_status = dish_status::isValid(status);  // trạng thái lạ/rỗng = không lọc
  std::vector<Product> filtered;
  for (auto& d : all) {
    if (category_id && d.category_id != *category_id) continue;
    if (use_status && d.status != status) continue;
    if (!key.empty() && normalizeText(d.code).find(key) == std::string::npos &&
        normalizeText(d.name).find(key) == std::string::npos)
      continue;
    filtered.push_back(std::move(d));
  }
  fillFinalPrice(filtered);
  std::stable_sort(filtered.begin(), filtered.end(), codeLess);  // admin: theo Dish ID tăng dần

  DishPage result = paginate(filtered, page, page_size_);
  result.categories = std::move(categories);
  result.summary = summary;
  if (filtered.empty()) result.message = msg::kAdminNoResult;
  return result;
}

Product MenuService::buildAndValidate(const DishInput& in, const std::optional<Product>& existing) {
  std::vector<std::string> errors;
  Product p;

  // Dish ID (chỉ kiểm tra khi thêm mới; khi sửa dùng mã cũ)
  if (existing) {
    p.code = existing->code;
  } else {
    p.code = toUpperAscii(trim(in.code));
    if (p.code.empty()) errors.push_back("Dish ID is required.");
    else if (!isCodeFormatValid(p.code))
      errors.push_back("Dish ID may only contain letters, digits, '-' and '_' (max 20 characters).");
    else if (repo_.codeExists(p.code)) errors.push_back("Dish ID already exists.");
  }

  // Name
  p.name = trim(in.name);
  if (p.name.empty()) errors.push_back("Dish name is required.");
  else if (utf8Length(p.name) > 150) errors.push_back("Dish name must not exceed 150 characters.");

  // Category
  const std::string category_text = trim(in.category_id);
  if (category_text.empty()) {
    errors.push_back("Category is required.");
  } else {
    bool found = false;
    if (category_text.size() <= 9 &&
        std::all_of(category_text.begin(), category_text.end(),
                    [](unsigned char c) { return std::isdigit(c) != 0; })) {
      const int id = std::stoi(category_text);
      for (const auto& c : repo_.findCategories())
        if (c.id == id) { p.category_id = id; p.category_name = c.name; found = true; }
    }
    if (!found) errors.push_back("Category is invalid.");
  }

  // Price (VND nguyên, >= 0)
  const std::string price_text = trim(in.price);
  if (price_text.empty()) {
    errors.push_back("Price is required.");
  } else {
    const DecimalText n = parseDecimalText(price_text);
    if (!n.valid) errors.push_back("Price must be a whole number.");
    else if (n.negative) errors.push_back("Price must not be less than 0.");
    else if (n.has_fraction) errors.push_back("Price must be a whole number.");
    else if (n.integer_digits.size() > 12) errors.push_back("Price is too large.");
    else p.price = std::stoll(n.integer_digits);
  }

  // Discount (0-100, để trống = 0)
  const std::string discount_text = trim(in.discount);
  p.discount = 0;
  if (!discount_text.empty()) {
    const DecimalText n = parseDecimalText(discount_text);
    const bool whole = n.valid && !n.has_fraction;
    if (!whole || n.negative || n.integer_digits.size() > 3 || std::stoi(n.integer_digits) > 100)
      errors.push_back("Discount must be a whole number between 0 and 100.");
    else p.discount = std::stoi(n.integer_digits);
  }

  // Status
  p.status = in.status;
  if (!dish_status::isValid(p.status)) errors.push_back("Status is invalid.");

  // Descriptions
  p.description = trim(in.description);
  p.detail = trim(in.detail);
  if (utf8Length(p.description) > 255)
    errors.push_back("Short description must not exceed 255 characters.");

  // Image (không bắt buộc): JPG/PNG, <= 2MB
  if (!in.image_name.empty()) {
    const auto dot = in.image_name.rfind('.');
    const std::string ext = dot == std::string::npos ? "" : toLowerAscii(in.image_name.substr(dot + 1));
    if (ext != "jpg" && ext != "jpeg" && ext != "png") errors.push_back("Image must be a JPG or PNG file.");
    else if (in.image_size > kMaxImageBytes) errors.push_back("Image must not exceed 2MB.");
    else p.image = "uploads/dishes/" + p.code + "." + (ext == "jpeg" ? "jpg" : ext);
  }

  if (!errors.empty()) throw ValidationError(errors);
  p.final_price = finalPrice(p.price, p.discount);
  return p;
}

Product MenuService::addDish(const DishInput& input) {
  return saving([&] {
    Product p = buildAndValidate(input, std::nullopt);
    repo_.insertDish(p);
    return p;
  });
}

Product MenuService::updateDish(const std::string& code, const DishInput& input) {
  return saving([&] {
    auto existing = repo_.findDishByCode(toUpperAscii(trim(code)));
    if (!existing) throw DishNotFoundError(msg::kDishNotFound);
    Product p = buildAndValidate(input, existing);
    if (p.image.empty()) p.image = existing->image;  // không chọn ảnh mới thì giữ ảnh cũ
    p.views = existing->views;
    p.sold = existing->sold;
    repo_.updateDish(p);
    return p;
  });
}

std::string MenuService::deleteDish(const std::string& code) {
  return saving([&]() -> std::string {
    auto dish = repo_.findDishByCode(toUpperAscii(trim(code)));
    if (!dish) throw DishNotFoundError(msg::kDishNotFound);
    if (repo_.isDishInOrders(dish->code)) {  // đã có trong đơn -> không xóa dòng, chuyển ngừng bán
      if (dish->status != dish_status::kDiscontinued) repo_.markDiscontinued(dish->code);
      return "DISCONTINUED";
    }
    repo_.deleteDish(dish->code);
    return "DELETED";
  });
}

Product MenuService::getDish(const std::string& code) {
  auto dish = loading([&] { return repo_.findDishByCode(toUpperAscii(trim(code))); });
  if (!dish) throw DishNotFoundError(msg::kDishNotFound);
  dish->final_price = finalPrice(dish->price, dish->discount);
  return *dish;
}

std::vector<Category> MenuService::getCategories() {
  return loading([&] { return repo_.findCategories(); });
}
