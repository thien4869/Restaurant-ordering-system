#pragma once
#include <optional>
#include <stdexcept>
#include <string>
#include <vector>

#include "models/Product.h"
#include "repositories/IMenuRepository.h"

// Thông báo hiển thị cho người dùng (tiếng Anh, theo CONVENTIONS mục D).
namespace msg {
inline const std::string kEmptyCategory = "There are no dishes in this category yet";
inline const std::string kNotFound = "No matching dish found";
inline const std::string kEmptyKeyword = "Please enter a keyword.";
inline const std::string kAdminNoResult = "No matching results were found.";
inline const std::string kLoadError = "Unable to load the menu. Please try again.";
inline const std::string kSaveError = "Could not save the dish. Please try again.";
inline const std::string kDishNotFound = "Dish not found";
}  // namespace msg

class DataAccessError : public std::runtime_error { public: using std::runtime_error::runtime_error; };
class SaveError : public std::runtime_error { public: using std::runtime_error::runtime_error; };
class DishNotFoundError : public std::runtime_error { public: using std::runtime_error::runtime_error; };

class ValidationError : public std::runtime_error {
 public:
  explicit ValidationError(std::vector<std::string> errors)
      : std::runtime_error("Validation failed"), errors_(std::move(errors)) {}
  const std::vector<std::string>& errors() const { return errors_; }

 private:
  std::vector<std::string> errors_;
};

constexpr int kPageSize = 20;                          // CONVENTIONS mục D
constexpr long long kMaxImageBytes = 2LL * 1024 * 1024;  // ảnh tối đa 2MB (Figure 6)

enum class SortKey {
  NEWEST,
  PRICE_ASC, PRICE_DESC,
  DISCOUNT_ASC, DISCOUNT_DESC,
  ORDERS_ASC, ORDERS_DESC,
  // Backward-compatible aliases: the default UI choice is highest first.
  DISCOUNT = DISCOUNT_DESC,
  ORDERS = ORDERS_DESC
};
// "price" = PRICE_ASC; chuỗi lạ -> NEWEST
SortKey parseSortKey(const std::string& text);

struct DishSummary {
  int total = 0, available = 0, sold_out = 0, discontinued = 0;
};

struct DishPage {
  std::vector<Product> items;
  int page = 1;
  int total_pages = 1;
  int total_items = 0;
  std::string message;                 // rỗng nếu không có thông báo
  std::vector<Category> categories;
  DishSummary summary;                 // chỉ dùng cho Admin
};

// Dữ liệu thô từ form Add/Update Dish (toàn chuỗi, Service tự kiểm tra).
struct DishInput {
  std::string code, name, category_id, price, discount, status, description, detail;
  std::string image_name;     // tên file ảnh người dùng chọn, rỗng nếu không chọn
  long long image_size = 0;   // dung lượng byte
};

// Lớp nghiệp vụ Thực đơn (kiểm tra quy tắc ở đây; không có SQL, không in ra màn hình).
class MenuService {
 public:
  explicit MenuService(IMenuRepository& repository, int page_size = kPageSize)
      : repo_(repository), page_size_(page_size) {}

  // --- Khách ---
  DishPage browseMenu(std::optional<int> category_id, SortKey sort, int page);
  DishPage searchDishes(const std::string& keyword, SortKey sort, int page);
  Product getDetail(const std::string& code);  // +1 lượt xem; ném DishNotFoundError nếu không có/đã ngừng bán

  // --- Admin (Manage Dishes) ---
  DishPage manageDishes(const std::string& keyword, std::optional<int> category_id,
                        const std::string& status, int page);
  Product addDish(const DishInput& input);
  Product updateDish(const std::string& code, const DishInput& input);  // Dish ID không đổi được
  std::string deleteDish(const std::string& code);  // "DELETED" hoặc "DISCONTINUED" (món đã có trong đơn)
  Product getDish(const std::string& code);          // lấy món để sửa, KHÔNG tăng lượt xem
  std::vector<Category> getCategories();

 private:
  Product buildAndValidate(const DishInput& input, const std::optional<Product>& existing);

  IMenuRepository& repo_;
  int page_size_;
};
