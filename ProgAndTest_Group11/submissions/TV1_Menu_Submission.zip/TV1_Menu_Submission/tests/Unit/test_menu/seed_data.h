#pragma once
// Sinh từ database/seed_menu.sql + 4 loại trong seed.sql - dùng cho unit test (FakeMenuRepository).
#include <string>
#include <vector>
#include "models/Category.h"
#include "models/Product.h"

inline std::vector<Category> seedCategories() {
  return {
      {1, "Main Course"},
      {2, "Appetizer"},
      {3, "Dessert"},
      {4, "Drink"},
  };
}

inline std::vector<Product> seedDishes() {
  std::vector<Product> v;
  auto add = [&](const char* code, const char* name, int cat, const char* cat_name, long long price, int discount,
                 const char* status, int views, int sold, const char* desc) {
    Product p; p.code = code; p.name = name; p.category_id = cat; p.category_name = cat_name; p.price = price;
    p.discount = discount; p.status = status; p.views = views; p.sold = sold; p.description = desc;
    v.push_back(p);
  };
  add("MN01", "Quinoa Power Bowl", 1, "Main Course", 65000, 0, "AVAILABLE", 188, 120, "Quinoa bowl with roasted vegetables and chickpeas.");
  add("MN02", "High Protein Bowl", 1, "Main Course", 60000, 0, "AVAILABLE", 164, 98, "Grilled chicken, grains and fresh greens.");
  add("MN03", "Balanced Green Bowl", 1, "Main Course", 55000, 0, "AVAILABLE", 142, 84, "Avocado, greens and herb-roasted chicken.");
  add("MN04", "Vegan Energy Bowl", 1, "Main Course", 60000, 0, "SOLD_OUT", 120, 66, "Plant-based bowl with roasted sweet potato.");
  add("MN05", "Salmon Avocado Salad", 2, "Appetizer", 68000, 10, "AVAILABLE", 98, 52, "Seared salmon, avocado and mixed greens.");
  add("MN06", "Grilled Steak & Asparagus", 1, "Main Course", 88000, 10, "AVAILABLE", 124, 86, "Pan-seared steak with roasted potatoes and asparagus.");
  add("MN07", "Berry Acai Bowl", 1, "Main Course", 52000, 0, "DISCONTINUED", 45, 12, "Acai blended with berries and granola.");
  add("MN08", "Caesar Chicken Salad", 2, "Appetizer", 59000, 0, "AVAILABLE", 77, 40, "Romaine, grilled chicken and parmesan.");
  add("MN09", "Greek Salad", 2, "Appetizer", 52000, 15, "AVAILABLE", 64, 31, "Tomato, cucumber, olives and feta.");
  add("MN10", "Gỏi cuốn tôm thịt", 2, "Appetizer", 45000, 0, "AVAILABLE", 110, 75, "Fresh rolls with shrimp, pork and herbs.");
  add("MN11", "Phở bò", 1, "Main Course", 55000, 0, "AVAILABLE", 210, 160, "Rice noodle soup with sliced beef.");
  add("MN12", "Bún chả Hà Nội", 1, "Main Course", 50000, 0, "AVAILABLE", 150, 102, "Grilled pork patties with vermicelli and herbs.");
  add("MN13", "Cơm tấm sườn bì chả", 1, "Main Course", 48000, 5, "AVAILABLE", 132, 90, "Broken rice with grilled pork chop.");
  add("MN14", "Bún bò Huế", 1, "Main Course", 52000, 0, "SOLD_OUT", 95, 58, "Spicy Hue-style beef noodle soup.");
  add("MN15", "Bánh mì thịt nướng", 1, "Main Course", 30000, 0, "AVAILABLE", 175, 140, "Crispy baguette with grilled pork.");
  add("MN16", "Salmon Teriyaki", 1, "Main Course", 95000, 20, "AVAILABLE", 88, 47, "Teriyaki glazed salmon with steamed rice.");
  add("MN17", "Chicken Curry Rice", 1, "Main Course", 58000, 0, "AVAILABLE", 70, 36, "Mild chicken curry served with rice.");
  add("MN18", "Cà phê sữa đá", 4, "Drink", 29000, 0, "AVAILABLE", 230, 190, "Vietnamese iced coffee with condensed milk.");
  add("MN19", "Trà đào cam sả", 4, "Drink", 35000, 10, "AVAILABLE", 140, 99, "Peach tea with orange and lemongrass.");
  add("MN20", "Nước ép cam", 4, "Drink", 32000, 0, "AVAILABLE", 85, 60, "Freshly squeezed orange juice.");
  add("MN21", "Sinh tố bơ", 4, "Drink", 38000, 0, "AVAILABLE", 100, 70, "Creamy avocado smoothie.");
  add("MN22", "Matcha Latte", 4, "Drink", 42000, 0, "AVAILABLE", 72, 44, "Matcha green tea with steamed milk.");
  add("MN23", "Detox Green Juice", 4, "Drink", 40000, 0, "SOLD_OUT", 60, 28, "Cold-pressed celery, apple and spinach juice.");
  add("MN24", "Nước dừa tươi", 4, "Drink", 25000, 0, "DISCONTINUED", 40, 15, "Fresh young coconut water.");
  add("MN25", "Sinh tố dâu", 4, "Drink", 39000, 0, "AVAILABLE", 66, 38, "Strawberry smoothie.");
  add("MN26", "Trà tắc", 4, "Drink", 22000, 0, "AVAILABLE", 58, 33, "Iced tea with kumquat.");
  return v;
}
