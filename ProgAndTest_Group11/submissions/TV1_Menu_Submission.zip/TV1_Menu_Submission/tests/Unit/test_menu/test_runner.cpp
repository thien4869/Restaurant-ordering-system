#include "mini_test.h"

int main() {
  int failed = 0;
  for (const auto& t : mini::registry()) {
    mini::failures() = 0;
    try {
      t.fn();
    } catch (const std::exception& e) {
      mini::fail(__FILE__, __LINE__, std::string("unexpected exception: ") + e.what());
    } catch (...) {
      mini::fail(__FILE__, __LINE__, "unexpected non-standard exception");
    }
    if (mini::failures() > 0) { ++failed; std::cout << "[FAIL] " << t.suite << "." << t.name << "\n"; }
    else std::cout << "[ OK ] " << t.suite << "." << t.name << "\n";
  }
  std::cout << "\n" << (mini::registry().size() - failed) << "/" << mini::registry().size() << " tests passed\n";
  return failed == 0 ? 0 : 1;
}
