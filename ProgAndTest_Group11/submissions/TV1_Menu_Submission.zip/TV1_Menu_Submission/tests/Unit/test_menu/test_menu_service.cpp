// Unit test cho MenuService + hàm dùng chung (tiền, bỏ dấu). Không cần CSDL (dùng FakeMenuRepository).
#include <functional>

#include "common/FormatHelper.h"
#include "common/PriceHelper.h"
#include "common/TextHelper.h"
#include "fake_menu_repository.h"
#include "mini_test.h"

// ============================================================ hàm dùng chung
TEST(Pricing, discountExamples) {
  EXPECT_EQ(PriceHelper::priceAfterDiscount(100000, 10), 90000LL);
  EXPECT_EQ(PriceHelper::priceAfterDiscount(68000, 10), 61200LL);
  EXPECT_EQ(PriceHelper::priceAfterDiscount(95000, 20), 76000LL);
  EXPECT_EQ(PriceHelper::priceAfterDiscount(48000, 5), 45600LL);
  EXPECT_EQ(PriceHelper::priceAfterDiscount(35000, 10), 31500LL);
}
TEST(Pricing, boundaries) {
  EXPECT_EQ(PriceHelper::priceAfterDiscount(100, 0), 100LL);
  EXPECT_EQ(PriceHelper::priceAfterDiscount(100000, 100), 0LL);
  EXPECT_EQ(PriceHelper::priceAfterDiscount(0, 50), 0LL);
  EXPECT_EQ(PriceHelper::priceAfterDiscount(1, 50), 1LL);   // 0.5 làm tròn lên
  EXPECT_EQ(PriceHelper::priceAfterDiscount(10, 33), 7LL);  // 6.7 -> 7
}
TEST(Format, vnd) {
  EXPECT_EQ(formatVnd(61200), "61.200 VND");
  EXPECT_EQ(formatVnd(0), "0 VND");
  EXPECT_EQ(formatVnd(999), "999 VND");
  EXPECT_EQ(formatVnd(1234567), "1.234.567 VND");
}
TEST(TextUtils, removesVietnameseAccents) {
  EXPECT_EQ(normalizeText("Phở Bò"), "pho bo");
  EXPECT_EQ(normalizeText("ĐÀO"), "dao");
  EXPECT_EQ(normalizeText("Trà đào cam sả"), "tra dao cam sa");
  EXPECT_EQ(normalizeText("Bánh mì thịt nướng"), "banh mi thit nuong");
}
TEST(TextUtils, handlesDecomposedUnicode) {
  // "Phở Bò" gõ dạng tổ hợp (chữ + dấu rời)
  const std::string nfd = std::string("Ph") + "o" + "\xCC\x9B" + "\xCC\x89" + " B" + "o" + "\xCC\x80";
  EXPECT_EQ(normalizeText(nfd), "pho bo");
}
TEST(TextUtils, collapsesWhitespaceAndKeepsDigits) {
  EXPECT_EQ(normalizeText("  Matcha   Latte \t 2 "), "matcha latte 2");
  EXPECT_EQ(normalizeText("   "), "");
  EXPECT_EQ(normalizeText(""), "");
}
TEST(TextUtils, utf8LengthCountsCharacters) {
  EXPECT_EQ(utf8Length("Phở bò"), static_cast<std::size_t>(6));
  EXPECT_EQ(utf8Length("abc"), static_cast<std::size_t>(3));
}
TEST(Sort, parseSortKey) {
  EXPECT_TRUE(parseSortKey("price") == SortKey::PRICE_ASC);
  EXPECT_TRUE(parseSortKey("PRICE_DESC") == SortKey::PRICE_DESC);
  EXPECT_TRUE(parseSortKey("discount") == SortKey::DISCOUNT);
  EXPECT_TRUE(parseSortKey("orders") == SortKey::ORDERS);
  EXPECT_TRUE(parseSortKey("discount_asc") == SortKey::DISCOUNT_ASC);
  EXPECT_TRUE(parseSortKey("discount_desc") == SortKey::DISCOUNT_DESC);
  EXPECT_TRUE(parseSortKey("orders_asc") == SortKey::ORDERS_ASC);
  EXPECT_TRUE(parseSortKey("orders_desc") == SortKey::ORDERS_DESC);
  EXPECT_TRUE(parseSortKey("xyz") == SortKey::NEWEST);
  EXPECT_TRUE(parseSortKey("") == SortKey::NEWEST);
}

// ============================================================ Browse Menu
TEST(Browse, defaultIsNewestFirstWithoutDiscontinued) {
  FakeMenuRepository repo; MenuService svc(repo);
  DishPage page = svc.browseMenu(std::nullopt, SortKey::NEWEST, 1);
  EXPECT_EQ(page.items.size(), static_cast<std::size_t>(20));
  EXPECT_EQ(page.total_items, 24);
  EXPECT_EQ(firstCodes(page, 3), "MN26,MN25,MN23");
  EXPECT_EQ(codes(page).find("MN07"), std::string::npos);
  EXPECT_EQ(codes(page).find("MN24"), std::string::npos);
  EXPECT_TRUE(page.message.empty());
  EXPECT_EQ(page.categories.size(), static_cast<std::size_t>(4));
}
TEST(Browse, soldOutDishesStayListed) {
  FakeMenuRepository repo; MenuService svc(repo);
  DishPage page = svc.browseMenu(1, SortKey::NEWEST, 1);  // loại 1 = Main Course (gồm các món "bowl" và món chính)
  EXPECT_EQ(codes(page), "MN17,MN16,MN15,MN14,MN13,MN12,MN11,MN06,MN04,MN03,MN02,MN01");
  EXPECT_EQ(page.items[3].status, dish_status::kSoldOut);  // MN14 Bún bò Huế
  EXPECT_EQ(page.items[8].status, dish_status::kSoldOut);  // MN04 Vegan Energy Bowl
}
TEST(Browse, filtersByCategory) {
  FakeMenuRepository repo; MenuService svc(repo);
  DishPage salads = svc.browseMenu(2, SortKey::NEWEST, 1);
  EXPECT_EQ(codes(salads), "MN10,MN09,MN08,MN05");
  DishPage drinks = svc.browseMenu(4, SortKey::NEWEST, 1);
  EXPECT_EQ(drinks.total_items, 8);  // MN24 ngừng bán nên không tính
}
TEST(Browse, emptyCategoryShowsMessage) {
  FakeMenuRepository repo; MenuService svc(repo);
  DishPage page = svc.browseMenu(3, SortKey::NEWEST, 1);  // loại 3 = Dessert (chưa có món)
  EXPECT_EQ(page.items.size(), static_cast<std::size_t>(0));
  EXPECT_EQ(page.message, "There are no dishes in this category yet");
}
TEST(Browse, paginates20PerPage) {
  FakeMenuRepository repo; MenuService svc(repo);
  DishPage p2 = svc.browseMenu(std::nullopt, SortKey::NEWEST, 2);
  EXPECT_EQ(codes(p2), "MN04,MN03,MN02,MN01");
  EXPECT_EQ(p2.page, 2);
  EXPECT_EQ(p2.total_pages, 2);
}
TEST(Browse, pageOutOfRangeIsClamped) {
  FakeMenuRepository repo; MenuService svc(repo);
  EXPECT_EQ(svc.browseMenu(std::nullopt, SortKey::NEWEST, 99).page, 2);
  EXPECT_EQ(svc.browseMenu(std::nullopt, SortKey::NEWEST, 0).page, 1);
  EXPECT_EQ(svc.browseMenu(std::nullopt, SortKey::NEWEST, -5).page, 1);
}
TEST(Browse, sortByPriceUsesDiscountedPrice) {
  FakeMenuRepository repo; MenuService svc(repo);
  EXPECT_EQ(firstCodes(svc.browseMenu(std::nullopt, SortKey::PRICE_ASC, 1), 4), "MN26,MN18,MN15,MN19");
  EXPECT_EQ(firstCodes(svc.browseMenu(std::nullopt, SortKey::PRICE_DESC, 1), 3), "MN06,MN16,MN01");
}
TEST(Browse, sortByDiscountAndOrders) {
  FakeMenuRepository repo; MenuService svc(repo);
  EXPECT_EQ(firstCodes(svc.browseMenu(std::nullopt, SortKey::DISCOUNT, 1), 6), "MN16,MN09,MN19,MN06,MN05,MN13");
  EXPECT_EQ(firstCodes(svc.browseMenu(std::nullopt, SortKey::ORDERS, 1), 3), "MN18,MN11,MN15");
  const auto discountAsc = svc.browseMenu(std::nullopt, SortKey::DISCOUNT_ASC, 1);
  EXPECT_EQ(discountAsc.items.front().discount, 0);
  bool discountAscending = true;
  for (std::size_t i = 1; i < discountAsc.items.size(); ++i)
    if (discountAsc.items[i - 1].discount > discountAsc.items[i].discount) discountAscending = false;
  EXPECT_TRUE(discountAscending);
  EXPECT_EQ(firstCodes(svc.browseMenu(std::nullopt, SortKey::ORDERS_ASC, 1), 3), "MN23,MN09,MN26");
}
TEST(Browse, fillsFinalPrice) {
  FakeMenuRepository repo; MenuService svc(repo);
  DishPage page = svc.browseMenu(2, SortKey::NEWEST, 1);
  for (const auto& d : page.items)
    if (d.code == "MN05") { EXPECT_EQ(d.final_price, 61200LL); EXPECT_EQ(d.price, 68000LL); }
}
TEST(Browse, databaseErrorBecomesDataAccessError) {
  FakeMenuRepository repo; MenuService svc(repo);
  repo.failing.insert("findVisibleDishes");
  EXPECT_THROW(svc.browseMenu(std::nullopt, SortKey::NEWEST, 1), DataAccessError);
  try { svc.browseMenu(std::nullopt, SortKey::NEWEST, 1); }
  catch (const DataAccessError& e) { EXPECT_EQ(std::string(e.what()), "Unable to load the menu. Please try again."); }
}

// ============================================================ Search Dish
TEST(Search, ignoresDiacriticsAndCase) {
  FakeMenuRepository repo; MenuService svc(repo);
  EXPECT_EQ(codes(svc.searchDishes("pho bo", SortKey::NEWEST, 1)), "MN11");
  EXPECT_EQ(codes(svc.searchDishes("PHỞ BÒ", SortKey::NEWEST, 1)), "MN11");
  EXPECT_EQ(codes(svc.searchDishes("Phở", SortKey::NEWEST, 1)), "MN11");
  EXPECT_EQ(codes(svc.searchDishes("dao", SortKey::NEWEST, 1)), "MN19");
  EXPECT_EQ(codes(svc.searchDishes("đào", SortKey::NEWEST, 1)), "MN19");
  EXPECT_EQ(codes(svc.searchDishes("ca phe", SortKey::NEWEST, 1)), "MN18");
  EXPECT_EQ(codes(svc.searchDishes("QUINOA", SortKey::NEWEST, 1)), "MN01");
}
TEST(Search, partialKeywordAndEnglishNames) {
  FakeMenuRepository repo; MenuService svc(repo);
  EXPECT_EQ(codes(svc.searchDishes("bun", SortKey::NEWEST, 1)), "MN14,MN12");
  EXPECT_EQ(codes(svc.searchDishes("bowl", SortKey::NEWEST, 1)), "MN04,MN03,MN02,MN01");
}
TEST(Search, excludesDiscontinuedButKeepsSoldOut) {
  FakeMenuRepository repo; MenuService svc(repo);
  DishPage gone = svc.searchDishes("berry", SortKey::NEWEST, 1);
  EXPECT_EQ(gone.message, "No matching dish found");
  EXPECT_EQ(svc.searchDishes("nuoc dua", SortKey::NEWEST, 1).message, "No matching dish found");
  DishPage sold = svc.searchDishes("vegan", SortKey::NEWEST, 1);
  EXPECT_EQ(codes(sold), "MN04");
  EXPECT_EQ(sold.items[0].status, dish_status::kSoldOut);
}
TEST(Search, noMatchShowsMessage) {
  FakeMenuRepository repo; MenuService svc(repo);
  DishPage page = svc.searchDishes("xyz123", SortKey::NEWEST, 1);
  EXPECT_EQ(page.items.size(), static_cast<std::size_t>(0));
  EXPECT_EQ(page.message, "No matching dish found");
}
TEST(Search, emptyKeywordAsksForKeywordWithoutQueryingDishes) {
  FakeMenuRepository repo; MenuService svc(repo);
  for (const char* kw : {"", "   ", "\t"}) {
    DishPage page = svc.searchDishes(kw, SortKey::NEWEST, 1);
    EXPECT_EQ(page.message, "Please enter a keyword.");
    EXPECT_EQ(page.items.size(), static_cast<std::size_t>(0));
  }
  EXPECT_FALSE(repo.called("findVisibleDishes"));
}
TEST(Search, sortsResults) {
  FakeMenuRepository repo; MenuService svc(repo);
  EXPECT_EQ(codes(svc.searchDishes("bun", SortKey::PRICE_ASC, 1)), "MN12,MN14");
}
TEST(Search, paginatesResults) {
  FakeMenuRepository repo; MenuService svc(repo, 5);  // 17 món chứa chữ "a", 5 món/trang
  DishPage p1 = svc.searchDishes("a", SortKey::NEWEST, 1);
  EXPECT_EQ(p1.total_items, 17);
  EXPECT_EQ(p1.total_pages, 4);
  EXPECT_EQ(p1.items.size(), static_cast<std::size_t>(5));
  EXPECT_EQ(svc.searchDishes("a", SortKey::NEWEST, 4).items.size(), static_cast<std::size_t>(2));
}
TEST(Search, specialCharactersAreJustText) {
  FakeMenuRepository repo; MenuService svc(repo);
  EXPECT_EQ(svc.searchDishes("' OR 1=1 --", SortKey::NEWEST, 1).message, "No matching dish found");
  EXPECT_EQ(svc.searchDishes("<script>alert(1)</script>", SortKey::NEWEST, 1).message, "No matching dish found");
}

// ============================================================ View Dish Details
TEST(Detail, returnsDishAndCountsView) {
  FakeMenuRepository repo; MenuService svc(repo);
  Product d = svc.getDetail("MN06");
  EXPECT_EQ(d.name, "Grilled Steak & Asparagus");
  EXPECT_EQ(d.views, 125);
  EXPECT_EQ(d.sold, 86);
  EXPECT_EQ(d.final_price, 79200LL);
  EXPECT_EQ(repo.dishes["MN06"].views, 125);
  EXPECT_EQ(svc.getDetail("mn06").views, 126);  // mở lại: +1 nữa; mã không phân biệt hoa thường
}
TEST(Detail, soldOutDishCanBeViewed) {
  FakeMenuRepository repo; MenuService svc(repo);
  EXPECT_EQ(svc.getDetail("MN04").status, dish_status::kSoldOut);
}
TEST(Detail, discontinuedOrUnknownIsNotFoundAndViewsUnchanged) {
  FakeMenuRepository repo; MenuService svc(repo);
  EXPECT_THROW(svc.getDetail("MN07"), DishNotFoundError);
  EXPECT_THROW(svc.getDetail("XX99"), DishNotFoundError);
  EXPECT_EQ(repo.dishes["MN07"].views, 45);
  EXPECT_FALSE(repo.called("incrementViews"));
}
TEST(Detail, databaseError) {
  FakeMenuRepository repo; MenuService svc(repo);
  repo.failing.insert("findDishByCode");
  EXPECT_THROW(svc.getDetail("MN06"), DataAccessError);
}

// ============================================================ Manage Dishes: danh sách
TEST(ManageList, summaryCountsAllStatuses) {
  FakeMenuRepository repo; MenuService svc(repo);
  DishPage page = svc.manageDishes("", std::nullopt, "", 1);
  EXPECT_EQ(page.summary.total, 26);
  EXPECT_EQ(page.summary.available, 21);
  EXPECT_EQ(page.summary.sold_out, 3);
  EXPECT_EQ(page.summary.discontinued, 2);
}
TEST(ManageList, sortedByCodeAnd20PerPageIncludingDiscontinued) {
  FakeMenuRepository repo; MenuService svc(repo);
  DishPage p1 = svc.manageDishes("", std::nullopt, "", 1);
  EXPECT_EQ(p1.items.size(), static_cast<std::size_t>(20));
  EXPECT_EQ(firstCodes(p1, 3), "MN01,MN02,MN03");
  EXPECT_EQ(codes(svc.manageDishes("", std::nullopt, "", 2)), "MN21,MN22,MN23,MN24,MN25,MN26");
}
TEST(ManageList, searchByCodeOrNameIgnoringAccents) {
  FakeMenuRepository repo; MenuService svc(repo);
  EXPECT_EQ(codes(svc.manageDishes("mn05", std::nullopt, "", 1)), "MN05");
  EXPECT_EQ(codes(svc.manageDishes("pho", std::nullopt, "", 1)), "MN11");
  EXPECT_EQ(codes(svc.manageDishes("Nước dừa", std::nullopt, "", 1)), "MN24");  // món ngừng bán vẫn tìm được
}
TEST(ManageList, filtersByCategoryAndStatus) {
  FakeMenuRepository repo; MenuService svc(repo);
  EXPECT_EQ(svc.manageDishes("", 4, "", 1).total_items, 9);
  EXPECT_EQ(codes(svc.manageDishes("", std::nullopt, "SOLD_OUT", 1)), "MN04,MN14,MN23");
  EXPECT_EQ(codes(svc.manageDishes("", std::nullopt, "DISCONTINUED", 1)), "MN07,MN24");
  EXPECT_EQ(codes(svc.manageDishes("", 4, "SOLD_OUT", 1)), "MN23");
  EXPECT_EQ(svc.manageDishes("", std::nullopt, "FOO", 1).total_items, 26);  // trạng thái lạ = không lọc
}
TEST(ManageList, noMatchShowsMessage) {
  FakeMenuRepository repo; MenuService svc(repo);
  EXPECT_EQ(svc.manageDishes("zzz", std::nullopt, "", 1).message, "No matching results were found.");
}

// ============================================================ Manage Dishes: Add
TEST(AddDish, savesValidDish) {
  FakeMenuRepository repo; MenuService svc(repo);
  Product p = svc.addDish(validInput());
  EXPECT_EQ(p.code, "MN27");
  EXPECT_EQ(p.price, 25000LL);
  EXPECT_EQ(p.final_price, 25000LL);
  EXPECT_EQ(p.views, 0);
  EXPECT_EQ(p.category_name, "Dessert");
  EXPECT_TRUE(repo.dishes.count("MN27") == 1);
  EXPECT_EQ(repo.dishes["MN27"].name, "Chè ba màu");
}
TEST(AddDish, codeIsUppercasedAndDiscountDefaultsToZero) {
  FakeMenuRepository repo; MenuService svc(repo);
  DishInput in = validInput();
  in.code = " mn27 "; in.discount = "";
  Product p = svc.addDish(in);
  EXPECT_EQ(p.code, "MN27");
  EXPECT_EQ(p.discount, 0);
}
TEST(AddDish, requiredFieldsMissing) {
  FakeMenuRepository repo; MenuService svc(repo);
  auto e = errorsOf([&] { svc.addDish(DishInput{}); });
  EXPECT_TRUE(has(e, "Dish ID is required."));
  EXPECT_TRUE(has(e, "Dish name is required."));
  EXPECT_TRUE(has(e, "Category is required."));
  EXPECT_TRUE(has(e, "Price is required."));
  EXPECT_EQ(repo.dishes.size(), static_cast<std::size_t>(26));
  EXPECT_FALSE(repo.called("insertDish"));
}
TEST(AddDish, duplicateCodeRejectedCaseInsensitively) {
  FakeMenuRepository repo; MenuService svc(repo);
  DishInput in = validInput();
  in.code = "MN01";
  EXPECT_TRUE(has(errorsOf([&] { svc.addDish(in); }), "Dish ID already exists."));
  in.code = "mn01";
  EXPECT_TRUE(has(errorsOf([&] { svc.addDish(in); }), "Dish ID already exists."));
}
TEST(AddDish, codeFormat) {
  FakeMenuRepository repo; MenuService svc(repo);
  DishInput in = validInput();
  in.code = "MN 27!";
  EXPECT_TRUE(has(errorsOf([&] { svc.addDish(in); }),
                  "Dish ID may only contain letters, digits, '-' and '_' (max 20 characters)."));
  in.code = std::string(21, 'A');
  EXPECT_EQ(errorsOf([&] { svc.addDish(in); }).size(), static_cast<std::size_t>(1));
}
TEST(AddDish, priceRules) {
  FakeMenuRepository repo; MenuService svc(repo);
  DishInput in = validInput();
  in.price = "-1";
  EXPECT_TRUE(has(errorsOf([&] { svc.addDish(in); }), "Price must not be less than 0."));
  in.price = "abc";
  EXPECT_TRUE(has(errorsOf([&] { svc.addDish(in); }), "Price must be a whole number."));
  in.price = "12.5";
  EXPECT_TRUE(has(errorsOf([&] { svc.addDish(in); }), "Price must be a whole number."));
  in.price = "1000000000000";
  EXPECT_TRUE(has(errorsOf([&] { svc.addDish(in); }), "Price is too large."));
  in.price = "0";  // biên: giá 0 hợp lệ
  EXPECT_EQ(svc.addDish(in).price, 0LL);
  in.code = "MN28"; in.price = "0025000";
  EXPECT_EQ(svc.addDish(in).price, 25000LL);
  in.code = "MN29"; in.price = "999999999999";
  EXPECT_EQ(svc.addDish(in).price, 999999999999LL);
}
TEST(AddDish, discountRules) {
  FakeMenuRepository repo; MenuService svc(repo);
  const std::string bad = "Discount must be a whole number between 0 and 100.";
  DishInput in = validInput();
  for (const char* v : {"101", "-1", "abc", "10.5", "1000"}) {
    in.discount = v;
    EXPECT_TRUE(has(errorsOf([&] { svc.addDish(in); }), bad));
  }
  in.discount = "0";
  EXPECT_EQ(svc.addDish(in).discount, 0);
  in.code = "MN28"; in.discount = "100";  // biên: giảm 100% hợp lệ, giá sau giảm = 0
  Product p = svc.addDish(in);
  EXPECT_EQ(p.discount, 100);
  EXPECT_EQ(p.final_price, 0LL);
  in.code = "MN29"; in.discount = " 15 ";
  EXPECT_EQ(svc.addDish(in).discount, 15);
}
TEST(AddDish, categoryMustExist) {
  FakeMenuRepository repo; MenuService svc(repo);
  DishInput in = validInput();
  in.category_id = "99";
  EXPECT_TRUE(has(errorsOf([&] { svc.addDish(in); }), "Category is invalid."));
  in.category_id = "x";
  EXPECT_TRUE(has(errorsOf([&] { svc.addDish(in); }), "Category is invalid."));
}
TEST(AddDish, statusMustBeKnown) {
  FakeMenuRepository repo; MenuService svc(repo);
  DishInput in = validInput();
  in.status = "FOO";
  EXPECT_TRUE(has(errorsOf([&] { svc.addDish(in); }), "Status is invalid."));
  in.status = "SOLD_OUT";
  EXPECT_EQ(svc.addDish(in).status, dish_status::kSoldOut);
}
TEST(AddDish, nameLengthCountsCharactersNotBytes) {
  FakeMenuRepository repo; MenuService svc(repo);
  DishInput in = validInput();
  std::string long_name;
  for (int i = 0; i < 150; ++i) long_name += "ơ";  // 150 ký tự, 300 byte
  in.name = long_name;
  EXPECT_EQ(svc.addDish(in).name, long_name);
  in.code = "MN28"; in.name = long_name + "a";
  EXPECT_TRUE(has(errorsOf([&] { svc.addDish(in); }), "Dish name must not exceed 150 characters."));
}
TEST(AddDish, imageRules) {
  FakeMenuRepository repo; MenuService svc(repo);
  DishInput in = validInput();
  in.image_name = "pic.gif"; in.image_size = 1000;
  EXPECT_TRUE(has(errorsOf([&] { svc.addDish(in); }), "Image must be a JPG or PNG file."));
  in.image_name = "pic";
  EXPECT_TRUE(has(errorsOf([&] { svc.addDish(in); }), "Image must be a JPG or PNG file."));
  in.image_name = "pic.png"; in.image_size = 2 * 1024 * 1024 + 1;
  EXPECT_TRUE(has(errorsOf([&] { svc.addDish(in); }), "Image must not exceed 2MB."));
  in.image_name = "pic.PNG"; in.image_size = 2 * 1024 * 1024;  // biên: đúng 2MB hợp lệ
  EXPECT_EQ(svc.addDish(in).image, "uploads/dishes/MN27.png");
  in.code = "MN28"; in.image_name = "a.jpeg"; in.image_size = 10;
  EXPECT_EQ(svc.addDish(in).image, "uploads/dishes/MN28.jpg");
}
TEST(AddDish, reportsAllErrorsTogether) {
  FakeMenuRepository repo; MenuService svc(repo);
  DishInput in = validInput();
  in.price = "-5"; in.discount = "150";
  auto e = errorsOf([&] { svc.addDish(in); });
  EXPECT_TRUE(has(e, "Price must not be less than 0."));
  EXPECT_TRUE(has(e, "Discount must be a whole number between 0 and 100."));
}
TEST(AddDish, saveFailureBecomesSaveError) {
  FakeMenuRepository repo; MenuService svc(repo);
  repo.failing.insert("insertDish");
  EXPECT_THROW(svc.addDish(validInput()), SaveError);
  try { svc.addDish(validInput()); }
  catch (const SaveError& e) { EXPECT_EQ(std::string(e.what()), "Could not save the dish. Please try again."); }
  EXPECT_TRUE(repo.dishes.count("MN27") == 0);
}

// ============================================================ Manage Dishes: Update
static DishInput updateInput() {
  DishInput in;
  in.code = "MN99";  // phải bị bỏ qua: Dish ID không đổi được
  in.name = "High Protein Bowl Plus"; in.category_id = "1"; in.price = "62000"; in.discount = "5";
  in.status = "SOLD_OUT"; in.description = "New short"; in.detail = "New full";
  return in;
}
TEST(UpdateDish, changesFieldsButNotCodeViewsOrOrders) {
  FakeMenuRepository repo; MenuService svc(repo);
  repo.dishes["MN02"].image = "uploads/dishes/MN02.jpg";
  Product p = svc.updateDish("MN02", updateInput());
  EXPECT_EQ(p.code, "MN02");
  const Product& stored = repo.dishes["MN02"];
  EXPECT_EQ(stored.name, "High Protein Bowl Plus");
  EXPECT_EQ(stored.price, 62000LL);
  EXPECT_EQ(stored.discount, 5);
  EXPECT_EQ(stored.status, dish_status::kSoldOut);
  EXPECT_EQ(stored.views, 164);
  EXPECT_EQ(stored.sold, 98);
  EXPECT_EQ(stored.image, "uploads/dishes/MN02.jpg");  // không chọn ảnh mới -> giữ ảnh cũ
  EXPECT_TRUE(repo.dishes.count("MN99") == 0);
}
TEST(UpdateDish, newImageReplacesOld) {
  FakeMenuRepository repo; MenuService svc(repo);
  DishInput in = updateInput();
  in.image_name = "new.png"; in.image_size = 100;
  EXPECT_EQ(svc.updateDish("mn02", in).image, "uploads/dishes/MN02.png");  // mã không phân biệt hoa thường
}
TEST(UpdateDish, canSetDiscontinued) {
  FakeMenuRepository repo; MenuService svc(repo);
  DishInput in = updateInput();
  in.status = "DISCONTINUED";
  svc.updateDish("MN02", in);
  EXPECT_EQ(repo.dishes["MN02"].status, dish_status::kDiscontinued);
}
TEST(UpdateDish, invalidDataLeavesDishUnchanged) {
  FakeMenuRepository repo; MenuService svc(repo);
  DishInput in = updateInput();
  in.price = "-10";
  EXPECT_TRUE(has(errorsOf([&] { svc.updateDish("MN02", in); }), "Price must not be less than 0."));
  EXPECT_EQ(repo.dishes["MN02"].price, 60000LL);
  EXPECT_FALSE(repo.called("updateDish"));
}
TEST(UpdateDish, unknownDish) {
  FakeMenuRepository repo; MenuService svc(repo);
  EXPECT_THROW(svc.updateDish("MN99", updateInput()), DishNotFoundError);
}

// ============================================================ Manage Dishes: Delete
TEST(DeleteDish, dishInOrdersBecomesDiscontinued) {
  FakeMenuRepository repo; MenuService svc(repo);
  repo.in_orders.insert("MN01");
  EXPECT_EQ(svc.deleteDish("MN01"), "DISCONTINUED");
  EXPECT_TRUE(repo.dishes.count("MN01") == 1);
  EXPECT_EQ(repo.dishes["MN01"].status, dish_status::kDiscontinued);
  EXPECT_FALSE(repo.called("deleteDish"));
}
TEST(DeleteDish, dishWithoutOrdersIsRemoved) {
  FakeMenuRepository repo; MenuService svc(repo);
  EXPECT_EQ(svc.deleteDish("mn02"), "DELETED");
  EXPECT_TRUE(repo.dishes.count("MN02") == 0);
}
TEST(DeleteDish, alreadyDiscontinuedWithOrdersStaysDiscontinued) {
  FakeMenuRepository repo; MenuService svc(repo);
  repo.in_orders.insert("MN07");
  EXPECT_EQ(svc.deleteDish("MN07"), "DISCONTINUED");
  EXPECT_FALSE(repo.called("markDiscontinued"));
}
TEST(DeleteDish, unknownDish) {
  FakeMenuRepository repo; MenuService svc(repo);
  EXPECT_THROW(svc.deleteDish("MN99"), DishNotFoundError);
}
TEST(DeleteDish, databaseFailureBecomesSaveError) {
  FakeMenuRepository repo; MenuService svc(repo);
  repo.failing.insert("deleteDish");
  EXPECT_THROW(svc.deleteDish("MN02"), SaveError);
  EXPECT_TRUE(repo.dishes.count("MN02") == 1);
}
