#include <stdexcept>

#include "fake_menu_repository.h"
#include "mini_test.h"
#include "presentation/controllers/BrowseMenuController.h"
#include "presentation/controllers/SearchDishController.h"
#include "presentation/controllers/DishDetailsController.h"
#include "presentation/controllers/ManageDishController.h"

namespace {
struct FakeAuth {
  bool logged_in = false;
  bool admin = false;
  bool isLoggedIn() const { return logged_in; }
  bool canAccessAdmin() const { return logged_in && admin; }
};
}

TEST(FigmaControllers, browseReturnsFirstPage) {
  FakeMenuRepository repo;
  MenuService service(repo);
  BrowseMenuController controller(service);
  const DishPage page = controller.execute(std::nullopt, SortKey::NEWEST, 1);
  EXPECT_EQ(page.items.size(), static_cast<std::size_t>(20));
  EXPECT_EQ(page.items.front().code, "MN26");
}

TEST(FigmaControllers, searchSupportsVietnameseWithoutDiacritics) {
  FakeMenuRepository repo;
  MenuService service(repo);
  SearchDishController controller(service);
  const DishPage page = controller.execute("pho bo");
  EXPECT_EQ(page.items.size(), static_cast<std::size_t>(1));
  EXPECT_EQ(page.items.front().code, "MN11");
}

TEST(FigmaControllers, openingDetailsIncrementsViewsOnce) {
  FakeMenuRepository repo;
  MenuService service(repo);
  DishDetailsController controller(service);
  const Product dish = controller.execute("MN11");
  EXPECT_EQ(dish.views, 211);
  EXPECT_EQ(repo.dishes.at("MN11").views, 211);
}

TEST(FigmaControllers, manageDishControllerRequiresAdminAuth) {
  FakeMenuRepository repo;
  MenuService service(repo);
  ManageDishController controller(service);
  FakeAuth guest;
  FakeAuth customer{true, false};
  FakeAuth admin{true, true};
  bool guestDenied = false;
  bool customerDenied = false;
  try { controller.list("", std::nullopt, "", 1, guest); }
  catch (const std::runtime_error&) { guestDenied = true; }
  try { controller.list("", std::nullopt, "", 1, customer); }
  catch (const std::runtime_error&) { customerDenied = true; }
  EXPECT_TRUE(guestDenied);
  EXPECT_TRUE(customerDenied);
  EXPECT_EQ(controller.list("", std::nullopt, "", 1, admin).summary.total, 26);
}
