// Kiểm thử màn hình console bằng stringstream: kiểm tra đúng thông báo/chữ trong đặc tả.
#include <sstream>

#include "fake_menu_repository.h"
#include "mini_test.h"
#include "presentation/admin/dishes/DishManagementScreen.h"
#include "presentation/customer/menu/MenuScreen.h"

namespace {

bool contains(const std::string& text, const std::string& part) { return text.find(part) != std::string::npos; }

std::string runMenu(FakeMenuRepository& repo, const std::string& input,
                    MenuScreen::AddToCartHandler handler = nullptr) {
  MenuService svc(repo);
  std::istringstream in(input);
  std::ostringstream out;
  MenuScreen(svc, in, out, handler).run();
  return out.str();
}

// "guest" = chưa đăng nhập; "customer" / "admin" = đã đăng nhập với vai trò đó (Auth của TV3)
Auth authAs(const std::string& role) {
  Auth auth;
  if (role != "guest") {
    User user;
    user.email = role + "@example.com";
    user.role = role;
    auth.login(user);
  }
  return auth;
}

std::string runAdmin(FakeMenuRepository& repo, const Auth& auth, const std::string& input) {
  MenuService svc(repo);
  std::istringstream in(input);
  std::ostringstream out;
  DishManagementScreen(svc, in, out, "build/test_static").run(auth);
  return out.str();
}

}  // namespace

TEST(MenuScreen, showsFirstPage) {
  FakeMenuRepository repo;
  std::string out = runMenu(repo, "q\n");
  EXPECT_TRUE(contains(out, "Our Menu"));
  EXPECT_TRUE(contains(out, "[All Dishes]"));
  EXPECT_TRUE(contains(out, "Page 1/2"));
  EXPECT_TRUE(contains(out, "MN05 | Salmon Avocado Salad | Appetizer | Available | 61.200 VND (was 68.000 VND, 10% OFF)"));
  EXPECT_FALSE(contains(out, "Berry Acai Bowl"));  // ngừng bán
}
TEST(MenuScreen, categoryTabShowsSoldOut) {
  FakeMenuRepository repo;
  std::string out = runMenu(repo, "c 1\nq\n");
  EXPECT_TRUE(contains(out, "[Main Course]"));
  EXPECT_TRUE(contains(out, "Vegan Energy Bowl | Main Course | Sold Out"));
}
TEST(MenuScreen, emptyCategoryMessage) {
  FakeMenuRepository repo;
  EXPECT_TRUE(contains(runMenu(repo, "c 3\nq\n"), "There are no dishes in this category yet"));
}
TEST(MenuScreen, searchFlows) {
  FakeMenuRepository repo;
  std::string found = runMenu(repo, "s pho bo\nq\n");
  EXPECT_TRUE(contains(found, "MN11 | Phở bò"));
  EXPECT_FALSE(contains(found, "Quinoa Power Bowl"));
  EXPECT_TRUE(contains(runMenu(repo, "s\nq\n"), "Please enter a keyword."));
  EXPECT_TRUE(contains(runMenu(repo, "s xyz\nq\n"), "No matching dish found"));
}
TEST(MenuScreen, sortAndPageCommands) {
  FakeMenuRepository repo;
  std::string out = runMenu(repo, "o price\nn\nq\n");
  EXPECT_TRUE(contains(out, "Sort by: Price (low to high)"));
  EXPECT_TRUE(contains(out, "Page 2/2"));
}
TEST(MenuScreen, dishDetailCountsViews) {
  FakeMenuRepository repo;
  std::string out = runMenu(repo, "d MN06\nb\nq\n");
  EXPECT_TRUE(contains(out, "Dish ID: #MN06 | Category: Main Course | Status: Available"));
  EXPECT_TRUE(contains(out, "Price: 79.200 VND (was 88.000 VND, 10% OFF)"));
  EXPECT_TRUE(contains(out, "Views: 125 | Ordered: 86"));
}
TEST(MenuScreen, discontinuedDetailNotFound) {
  FakeMenuRepository repo;
  EXPECT_TRUE(contains(runMenu(repo, "d MN07\nq\n"), "Dish not found"));
}
TEST(MenuScreen, addToCartUsesHandlerAndBlocksSoldOut) {
  FakeMenuRepository repo;
  std::string added_code;
  int added_qty = 0;
  auto handler = [&](const std::string& code, int qty) { added_code = code; added_qty = qty; };
  std::string out = runMenu(repo, "d MN06\na 2\nb\nq\n", handler);
  EXPECT_EQ(added_code, "MN06");
  EXPECT_EQ(added_qty, 2);
  EXPECT_TRUE(contains(out, "Added to cart."));

  added_code.clear();
  std::string sold = runMenu(repo, "d MN04\na\nb\nq\n", handler);
  EXPECT_TRUE(contains(sold, "This dish is sold out."));
  EXPECT_EQ(added_code, "");
  EXPECT_TRUE(contains(runMenu(repo, "d MN06\na\nb\nq\n"), "The cart is not available yet."));
}
TEST(MenuScreen, databaseErrorOffersRetry) {
  FakeMenuRepository repo;
  repo.failing.insert("findVisibleDishes");
  std::string out = runMenu(repo, "q\n");
  EXPECT_TRUE(contains(out, "Unable to load the menu. Please try again."));
  EXPECT_TRUE(contains(out, "try again"));
}

TEST(DishScreen, onlyAdminCanEnter) {
  FakeMenuRepository repo;
  EXPECT_TRUE(contains(runAdmin(repo, authAs("guest"), "q\n"), "Please log in as an administrator"));
  EXPECT_TRUE(contains(runAdmin(repo, authAs("customer"), "q\n"), "Access denied"));
  EXPECT_FALSE(contains(runAdmin(repo, authAs("customer"), "q\n"), "DISH ID"));
}
TEST(DishScreen, listShowsSummaryAndFilters) {
  FakeMenuRepository repo;
  std::string out = runAdmin(repo, authAs("admin"), "t sold_out\nq\n");
  EXPECT_TRUE(contains(out, "Total Dishes: 26 | Available: 21 | Sold Out: 3 | Discontinued: 2"));
  EXPECT_TRUE(contains(out, "MN04 | Vegan Energy Bowl | Main Course | 60.000 VND | 0% | 120/66 | Sold Out"));
  EXPECT_TRUE(contains(runAdmin(repo, authAs("admin"), "s zzz\nq\n"), "No matching results were found."));
}
TEST(DishScreen, addFlowSavesDish) {
  FakeMenuRepository repo;
  // Dish ID, Category, Name, Price, rồi Enter cho Discount/Status/Image/Short/Full
  std::string out = runAdmin(repo, authAs("admin"), std::string("add\nMN27\n3\nChè ba màu\n25000\n") + "\n\n\n\n\n" + "q\n");
  EXPECT_TRUE(contains(out, "Dish added successfully."));
  EXPECT_TRUE(repo.dishes.count("MN27") == 1);
  EXPECT_EQ(repo.dishes["MN27"].status, dish_status::kAvailable);
}
TEST(DishScreen, addFlowShowsValidationErrorsAndCanCancel) {
  FakeMenuRepository repo;
  std::string out = runAdmin(repo, authAs("admin"), std::string("add\nMN01\n1\nX\n-5\n") + "\n\n\n\n\n" + "cancel\nq\n");
  EXPECT_TRUE(contains(out, "Error: Dish ID already exists."));
  EXPECT_TRUE(contains(out, "Error: Price must not be less than 0."));
  EXPECT_TRUE(contains(out, "Cancelled."));
  EXPECT_EQ(repo.dishes.size(), static_cast<std::size_t>(26));
}
TEST(DishScreen, editFlowKeepsValuesOnEnter) {
  FakeMenuRepository repo;
  // Enter ở mọi trường, chỉ đổi giá
  std::string out = runAdmin(repo, authAs("admin"), std::string("edit MN02\n") + "\n\n" + "70000\n" + "\n\n\n\n\n" + "q\n");
  EXPECT_TRUE(contains(out, "Dish updated successfully."));
  EXPECT_EQ(repo.dishes["MN02"].price, 70000LL);
  EXPECT_EQ(repo.dishes["MN02"].name, "High Protein Bowl");
}
TEST(DishScreen, deleteFlow) {
  FakeMenuRepository repo;
  EXPECT_TRUE(contains(runAdmin(repo, authAs("admin"), "del MN02\nn\nq\n"), "Cancelled."));
  EXPECT_TRUE(repo.dishes.count("MN02") == 1);
  EXPECT_TRUE(contains(runAdmin(repo, authAs("admin"), "del MN02\ny\nq\n"), "Dish deleted successfully."));
  EXPECT_TRUE(repo.dishes.count("MN02") == 0);

  repo.in_orders.insert("MN01");
  EXPECT_TRUE(contains(runAdmin(repo, authAs("admin"), "del MN01\ny\nq\n"), "set to Discontinued"));
  EXPECT_EQ(repo.dishes["MN01"].status, dish_status::kDiscontinued);
}
