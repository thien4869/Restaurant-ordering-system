#pragma once
// Khung test tối giản (không cần cài thêm gì). Cú pháp giống GoogleTest: TEST, EXPECT_EQ,
// EXPECT_TRUE, EXPECT_FALSE, EXPECT_THROW. Nhóm dùng GoogleTest thì chỉ cần đổi #include.
#include <functional>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

namespace mini {
struct TestCase {
  std::string suite, name;
  std::function<void()> fn;
};
inline std::vector<TestCase>& registry() { static std::vector<TestCase> r; return r; }
inline int& failures() { static int n = 0; return n; }  // số lỗi của test đang chạy
struct Registrar {
  Registrar(const char* suite, const char* name, std::function<void()> fn) {
    registry().push_back({suite, name, std::move(fn)});
  }
};
template <typename T> std::string str(const T& v) { std::ostringstream os; os << v; return os.str(); }
inline std::string str(bool v) { return v ? "true" : "false"; }
inline void fail(const char* file, int line, const std::string& what) {
  ++failures();
  std::cerr << file << ":" << line << ": FAILED " << what << "\n";
}
}  // namespace mini

#define TEST(suite, name)                                                      \
  static void suite##_##name();                                                \
  static mini::Registrar reg_##suite##_##name(#suite, #name, suite##_##name);  \
  static void suite##_##name()

#define EXPECT_TRUE(c) do { if (!(c)) mini::fail(__FILE__, __LINE__, "expected true: " #c); } while (0)
#define EXPECT_FALSE(c) do { if (c) mini::fail(__FILE__, __LINE__, "expected false: " #c); } while (0)
#define EXPECT_EQ(a, b)                                                                       \
  do {                                                                                        \
    auto _a = (a);                                                                            \
    auto _b = (b);                                                                            \
    if (!(_a == _b))                                                                          \
      mini::fail(__FILE__, __LINE__, std::string(#a " == " #b "   got [") + mini::str(_a) +   \
                                         "] vs [" + mini::str(_b) + "]");                     \
  } while (0)
#define EXPECT_THROW(stmt, ex)                                                      \
  do {                                                                              \
    bool _thrown = false;                                                           \
    try { stmt; } catch (const ex&) { _thrown = true; } catch (...) {}              \
    if (!_thrown) mini::fail(__FILE__, __LINE__, "expected " #ex " from: " #stmt);  \
  } while (0)
