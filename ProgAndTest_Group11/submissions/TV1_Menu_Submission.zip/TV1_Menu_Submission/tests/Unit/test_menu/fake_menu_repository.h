#pragma once
#include <algorithm>
#include <functional>
#include <map>
#include <set>
#include <stdexcept>

#include "repositories/IMenuRepository.h"
#include "seed_data.h"
#include "services/MenuService.h"

// Repository giả trong bộ nhớ: dữ liệu giống db/sample_menu_data.sql, có thể giả lập lỗi CSDL.
class FakeMenuRepository : public IMenuRepository {
 public:
  std::vector<Category> categories = seedCategories();
  std::map<std::string, Product> dishes;
  std::set<std::string> in_orders;  // mã món đã có trong đơn
  std::set<std::string> failing;    // tên hàm sẽ ném lỗi; "*" = mọi hàm
  std::vector<std::string> calls;

  FakeMenuRepository() { for (const auto& p : seedDishes()) dishes[p.code] = p; }

  bool called(const std::string& name) const {
    return std::find(calls.begin(), calls.end(), name) != calls.end();
  }

  std::vector<Category> findCategories() override { enter("findCategories"); return categories; }
  std::vector<Product> findVisibleDishes(std::optional<int> category_id) override {
    enter("findVisibleDishes");
    std::vector<Product> out;
    for (const auto& kv : dishes)
      if (kv.second.status != dish_status::kDiscontinued && (!category_id || kv.second.category_id == *category_id))
        out.push_back(kv.second);
    return out;
  }
  std::vector<Product> findAllDishes() override {
    enter("findAllDishes");
    std::vector<Product> out;
    for (const auto& kv : dishes) out.push_back(kv.second);
    return out;
  }
  std::optional<Product> findDishByCode(const std::string& code) override {
    enter("findDishByCode");
    auto it = dishes.find(code);
    if (it == dishes.end()) return std::nullopt;
    return it->second;
  }
  bool codeExists(const std::string& code) override { enter("codeExists"); return dishes.count(code) > 0; }
  bool isDishInOrders(const std::string& code) override { enter("isDishInOrders"); return in_orders.count(code) > 0; }
  void incrementViews(const std::string& code) override { enter("incrementViews"); dishes.at(code).views += 1; }
  void insertDish(const Product& d) override {
    enter("insertDish");
    Product p = d;
    for (const auto& c : categories) if (c.id == p.category_id) p.category_name = c.name;
    dishes[p.code] = p;
  }
  void updateDish(const Product& d) override {
    enter("updateDish");
    Product& p = dishes.at(d.code);
    p.name = d.name; p.category_id = d.category_id; p.price = d.price; p.discount = d.discount;
    p.status = d.status; p.image = d.image; p.description = d.description; p.detail = d.detail;
  }
  void markDiscontinued(const std::string& code) override { enter("markDiscontinued"); dishes.at(code).status = dish_status::kDiscontinued; }
  void deleteDish(const std::string& code) override { enter("deleteDish"); dishes.erase(code); }

 private:
  void enter(const std::string& name) {
    calls.push_back(name);
    if (failing.count(name) || failing.count("*")) throw std::runtime_error("database is down");
  }
};

// Ghép mã của các món trong trang: "MN04,MN03,MN02"
inline std::string codes(const DishPage& page) {
  std::string s;
  for (const auto& d : page.items) { if (!s.empty()) s += ","; s += d.code; }
  return s;
}

inline std::string firstCodes(const DishPage& page, std::size_t n) {
  std::string s;
  for (std::size_t i = 0; i < page.items.size() && i < n; ++i) { if (i) s += ","; s += page.items[i].code; }
  return s;
}

inline DishInput validInput() {
  DishInput in;
  in.code = "MN27"; in.name = "Chè ba màu"; in.category_id = "3"; in.price = "25000";
  in.discount = "0"; in.status = "AVAILABLE";
  return in;
}

inline std::vector<std::string> errorsOf(const std::function<void()>& action) {
  try { action(); } catch (const ValidationError& e) { return e.errors(); }
  return {};
}

inline bool has(const std::vector<std::string>& v, const std::string& s) {
  return std::find(v.begin(), v.end(), s) != v.end();
}
