// Kiểm thử MenuRepository (qua IDatabase) với schema.sql + seed.sql THẬT của nhóm (TV5), chạy trên SQLite trong bộ nhớ
// (SqliteDatabase::runMySqlScript đổi cú pháp MySQL). Nhờ vậy sai tên bảng/cột so với schema.sql sẽ bị test bắt ngay.
// Món ăn lấy từ seed.sql nếu đã dán database/seed_menu.sql vào, chưa thì nạp thêm seed_menu.sql.
#include <fstream>
#include <sstream>

#include "common/database/SqliteDatabase.h"
#include "fake_menu_repository.h"
#include "mini_test.h"
#include "repositories/MenuRepository.h"

namespace {

bool readIfExists(const std::string& relative, std::string& out) {
  std::ifstream file(std::string(PROJECT_ROOT) + "/" + relative);
  if (!file) return false;
  std::stringstream ss;
  ss << file.rdbuf();
  out = ss.str();
  return true;
}

// Ưu tiên file thật trong repo; không có thì dùng bản sao TV5 trong thư mục test.
std::string readFirst(const std::string& primary, const std::string& fallback) {
  std::string text;
  if (readIfExists(primary, text) || readIfExists(fallback, text)) return text;
  throw std::runtime_error("cannot read " + primary + " or " + fallback);
}

struct Db {
  SqliteDatabase conn{":memory:"};
  MenuRepository repo{conn};
  Db() {
    conn.runMySqlScript(readFirst("database/schema.sql", "tests/Unit/test_menu/tv5_copy/schema.sql"));
    conn.runMySqlScript(readFirst("database/seed.sql", "tests/Unit/test_menu/tv5_copy/seed.sql"));
    if (conn.query("SELECT COUNT(*) FROM products")[0][0] == "0") {
      std::string dishes;
      if (!readIfExists("database/seed_menu.sql", dishes)) throw std::runtime_error("cannot read database/seed_menu.sql");
      conn.runScript(dishes);
    }
  }
  // Dữ liệu phụ để thử xóa món / món đã có trong đơn (bảng users, carts, orders thuộc module khác)
  void addUser() {
    conn.runScript("INSERT OR IGNORE INTO users (email, password, name) VALUES ('c@x.com', 'hash', 'C')");
  }
  void putInCart(const std::string& code) {
    addUser();
    conn.runScript("INSERT OR IGNORE INTO carts (cart_id, user_email) VALUES (1, 'c@x.com');"
                   "INSERT INTO cart_items (cart_id, product_code, qty) VALUES (1, '" + code + "', 2)");
  }
  void putInOrder(const std::string& code) {
    addUser();
    conn.runScript("INSERT OR IGNORE INTO orders (order_number, user_email, shipping_id, ward_id, receiver_name, receiver_mobile, "
                   "receiver_address, total, payment_type) VALUES ('ORD-20261121-0001', 'c@x.com', 1, 1, 'C', '0900000000', 'Addr', 65000, 'CASH');"
                   "INSERT INTO order_details (order_number, product_code, qty, price) VALUES ('ORD-20261121-0001', '" + code + "', 1, 65000)");
  }
};

Product newDish() {
  Product p;
  p.code = "MN27"; p.name = "Chè ba màu"; p.category_id = 3; p.price = 25000; p.discount = 0;
  p.status = dish_status::kAvailable; p.description = "Sweet dessert"; p.detail = "Full";
  return p;
}

}  // namespace

TEST(Repository, loadsGroupSchemaAndSampleDishes) {
  Db db;
  EXPECT_EQ(db.repo.findCategories().size(), static_cast<std::size_t>(4));
  EXPECT_EQ(db.repo.findAllDishes().size(), static_cast<std::size_t>(26));
  EXPECT_EQ(db.repo.findVisibleDishes(std::nullopt).size(), static_cast<std::size_t>(24));
  EXPECT_EQ(db.repo.findVisibleDishes(1).size(), static_cast<std::size_t>(12));  // Main Course
  EXPECT_EQ(db.repo.findVisibleDishes(2).size(), static_cast<std::size_t>(4));   // Appetizer
  EXPECT_EQ(db.repo.findVisibleDishes(3).size(), static_cast<std::size_t>(0));   // Dessert (trống)
  EXPECT_EQ(db.repo.findVisibleDishes(4).size(), static_cast<std::size_t>(8));   // Drink
}
TEST(Repository, readsAllColumns) {
  Db db;
  auto d = db.repo.findDishByCode("MN06");
  EXPECT_TRUE(d.has_value());
  EXPECT_EQ(d->name, "Grilled Steak & Asparagus");
  EXPECT_EQ(d->category_name, "Main Course");
  EXPECT_EQ(d->price, 88000LL);
  EXPECT_EQ(d->discount, 10);
  EXPECT_EQ(d->status, dish_status::kAvailable);
  EXPECT_EQ(d->views, 124);
  EXPECT_EQ(d->sold, 86);
  EXPECT_EQ(d->image, "");  // NULL -> chuỗi rỗng
  EXPECT_EQ(d->description, "Pan-seared steak with roasted potatoes and asparagus.");
  EXPECT_TRUE(d->detail.find("A filling main course") != std::string::npos);
  EXPECT_EQ(db.repo.findDishByCode("MN11")->name, "Phở bò");  // UTF-8 giữ nguyên
  EXPECT_FALSE(db.repo.findDishByCode("XX99").has_value());
}
TEST(Repository, incrementViews) {
  Db db;
  db.repo.incrementViews("MN06");
  EXPECT_EQ(db.repo.findDishByCode("MN06")->views, 125);
}
TEST(Repository, insertUpdateMarkDiscontinued) {
  Db db;
  Product p = newDish();
  p.image = "uploads/dishes/MN27.png";
  db.repo.insertDish(p);
  EXPECT_TRUE(db.repo.codeExists("MN27"));
  auto saved = db.repo.findDishByCode("MN27");
  EXPECT_EQ(saved->image, "uploads/dishes/MN27.png");
  EXPECT_EQ(saved->category_name, "Dessert");
  EXPECT_EQ(saved->description, "Sweet dessert");
  EXPECT_EQ(saved->detail, "Full");
  EXPECT_EQ(saved->views, 0);
  EXPECT_EQ(saved->sold, 0);

  p.name = "Chè khúc bạch"; p.price = 30000; p.discount = 10; p.status = dish_status::kSoldOut; p.image = "";
  db.repo.updateDish(p);
  auto updated = db.repo.findDishByCode("MN27");
  EXPECT_EQ(updated->name, "Chè khúc bạch");
  EXPECT_EQ(updated->price, 30000LL);
  EXPECT_EQ(updated->discount, 10);
  EXPECT_EQ(updated->status, dish_status::kSoldOut);
  EXPECT_EQ(updated->image, "");

  db.repo.markDiscontinued("MN27");
  EXPECT_EQ(db.repo.findDishByCode("MN27")->status, dish_status::kDiscontinued);
  EXPECT_EQ(db.repo.findVisibleDishes(3).size(), static_cast<std::size_t>(0));
}
TEST(Repository, databaseConstraintsAreTheLastLineOfDefense) {
  Db db;
  Product dup = newDish();
  dup.code = "MN01";
  EXPECT_THROW(db.repo.insertDish(dup), std::runtime_error);  // trùng khóa chính
  Product bad_discount = newDish();
  bad_discount.discount = 101;
  EXPECT_THROW(db.repo.insertDish(bad_discount), std::runtime_error);  // CHECK discount 0-100
  Product bad_price = newDish();
  bad_price.price = -1;
  EXPECT_THROW(db.repo.insertDish(bad_price), std::runtime_error);  // CHECK price >= 0
  Product bad_category = newDish();
  bad_category.category_id = 99;
  EXPECT_THROW(db.repo.insertDish(bad_category), std::runtime_error);  // khóa ngoại categories
}
TEST(Repository, isDishInOrders) {
  Db db;
  db.putInOrder("MN01");
  EXPECT_TRUE(db.repo.isDishInOrders("MN01"));
  EXPECT_FALSE(db.repo.isDishInOrders("MN02"));
}
TEST(Repository, deleteRemovesDishAndItsCartItems) {
  Db db;
  db.putInCart("MN02");
  db.repo.deleteDish("MN02");  // nếu cart_items còn sót thì khóa ngoại sẽ làm câu lệnh này lỗi
  EXPECT_FALSE(db.repo.findDishByCode("MN02").has_value());
}
TEST(Repository, deleteFailsAndRollsBackWhenDishInOrders) {
  Db db;
  db.putInCart("MN01");
  db.putInOrder("MN01");
  EXPECT_THROW(db.repo.deleteDish("MN01"), std::runtime_error);  // vướng khóa ngoại order_details
  EXPECT_TRUE(db.repo.findDishByCode("MN01").has_value());
}
TEST(Repository, parameterBindingBlocksSqlInjection) {
  Db db;
  EXPECT_FALSE(db.repo.findDishByCode("MN01' OR '1'='1").has_value());
  EXPECT_FALSE(db.repo.codeExists("x'; DROP TABLE products; --"));
  EXPECT_EQ(db.repo.findAllDishes().size(), static_cast<std::size_t>(26));  // bảng vẫn còn nguyên
}

// ---- Service + CSDL thật (luồng end-to-end) ----
TEST(ServiceWithDatabase, searchIgnoresDiacritics) {
  Db db; MenuService svc(db.repo);
  EXPECT_EQ(codes(svc.searchDishes("pho bo", SortKey::NEWEST, 1)), "MN11");
  EXPECT_EQ(codes(svc.searchDishes("ca phe", SortKey::NEWEST, 1)), "MN18");
}
TEST(ServiceWithDatabase, browseMatchesSampleData) {
  Db db; MenuService svc(db.repo);
  DishPage p1 = svc.browseMenu(std::nullopt, SortKey::NEWEST, 1);
  EXPECT_EQ(p1.items.size(), static_cast<std::size_t>(20));
  EXPECT_EQ(p1.total_pages, 2);
  EXPECT_EQ(firstCodes(svc.browseMenu(std::nullopt, SortKey::PRICE_ASC, 1), 3), "MN26,MN18,MN15");
  EXPECT_EQ(svc.browseMenu(3, SortKey::NEWEST, 1).message, "There are no dishes in this category yet");
}
TEST(ServiceWithDatabase, addThenViewDetail) {
  Db db; MenuService svc(db.repo);
  DishInput in = validInput();
  in.discount = "10";
  svc.addDish(in);
  Product d = svc.getDetail("MN27");
  EXPECT_EQ(d.final_price, 22500LL);
  EXPECT_EQ(d.views, 1);
  EXPECT_EQ(d.category_name, "Dessert");
}
TEST(ServiceWithDatabase, deleteDishInOrdersKeepsRowAsDiscontinued) {
  Db db; MenuService svc(db.repo);
  db.putInOrder("MN01");
  db.putInCart("MN02");
  EXPECT_EQ(svc.deleteDish("MN01"), "DISCONTINUED");
  EXPECT_EQ(db.repo.findDishByCode("MN01")->status, dish_status::kDiscontinued);
  EXPECT_EQ(svc.deleteDish("MN02"), "DELETED");  // món đang nằm trong giỏ nhưng chưa có trong đơn
  EXPECT_FALSE(db.repo.findDishByCode("MN02").has_value());
}
