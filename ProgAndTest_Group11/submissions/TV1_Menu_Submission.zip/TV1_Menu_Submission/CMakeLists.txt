cmake_minimum_required(VERSION 3.16)
project(Group11_TV1_Menu LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

option(TV1_WITH_MYSQL "Build the MySQL/MariaDB IDatabase adapter" OFF)
option(TV1_BUILD_CONSOLE_DEMO "Build the optional console demo (Figma remains the UI design)" ON)
option(TV1_BUILD_TESTS "Build the unit and repository test suite" ON)

add_library(tv1_menu_core
    src/common/TextHelper.cpp
    src/common/FormatHelper.cpp
    src/common/PriceHelper.cpp
    src/repositories/MenuRepository.cpp
    src/services/MenuService.cpp
    src/presentation/controllers/BrowseMenuController.cpp
    src/presentation/controllers/SearchDishController.cpp
    src/presentation/controllers/DishDetailsController.cpp
)
target_include_directories(tv1_menu_core PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/src)

if(MSVC)
    target_compile_options(tv1_menu_core PRIVATE /W4 /utf-8)
else()
    target_compile_options(tv1_menu_core PRIVATE -Wall -Wextra -Wpedantic)
endif()

if(TV1_BUILD_TESTS OR TV1_BUILD_CONSOLE_DEMO)
    find_package(SQLite3 REQUIRED)
    add_library(tv1_sqlite_adapter src/common/database/SqliteDatabase.cpp)
    target_include_directories(tv1_sqlite_adapter PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/src)
    target_link_libraries(tv1_sqlite_adapter PUBLIC tv1_menu_core SQLite::SQLite3)
endif()

if(TV1_WITH_MYSQL)
    find_package(PkgConfig REQUIRED)
    pkg_check_modules(MYSQLCLIENT REQUIRED IMPORTED_TARGET mysqlclient)
    add_library(tv1_mysql_adapter src/common/database/MySqlDatabase.cpp)
    target_include_directories(tv1_mysql_adapter PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/src)
    target_link_libraries(tv1_mysql_adapter PUBLIC tv1_menu_core PkgConfig::MYSQLCLIENT)
    if(MSVC)
        target_compile_options(tv1_mysql_adapter PRIVATE /W4 /utf-8)
    else()
        target_compile_options(tv1_mysql_adapter PRIVATE -Wall -Wextra -Wpedantic)
    endif()
endif()

if(TV1_BUILD_CONSOLE_DEMO)
    add_executable(tv1_menu_demo
        src/MenuDemoMain.cpp
        src/presentation/customer/menu/MenuScreen.cpp
        src/presentation/admin/dishes/DishManagementScreen.cpp
    )
    target_include_directories(tv1_menu_demo PRIVATE
        ${CMAKE_CURRENT_SOURCE_DIR}/src
        ${CMAKE_CURRENT_SOURCE_DIR}/tests/Unit/test_menu/tv3_copy
    )
    target_link_libraries(tv1_menu_demo PRIVATE tv1_sqlite_adapter)
endif()

if(TV1_BUILD_TESTS)
    enable_testing()
    file(GLOB TV1_TEST_SOURCES CONFIGURE_DEPENDS tests/Unit/test_menu/*.cpp)
    add_executable(tv1_menu_tests
        ${TV1_TEST_SOURCES}
        src/presentation/customer/menu/MenuScreen.cpp
        src/presentation/admin/dishes/DishManagementScreen.cpp
    )
    target_include_directories(tv1_menu_tests PRIVATE
        ${CMAKE_CURRENT_SOURCE_DIR}/src
        ${CMAKE_CURRENT_SOURCE_DIR}/tests/Unit/test_menu
        ${CMAKE_CURRENT_SOURCE_DIR}/tests/Unit/test_menu/tv3_copy
    )
    target_compile_definitions(tv1_menu_tests PRIVATE PROJECT_ROOT=\"${CMAKE_CURRENT_SOURCE_DIR}\")
    target_link_libraries(tv1_menu_tests PRIVATE tv1_sqlite_adapter)
    add_test(NAME tv1_menu_unit_tests COMMAND tv1_menu_tests)
endif()
