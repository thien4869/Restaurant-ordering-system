# TV1 – Implementation report

## 1. Objective

Implement the Menu module of Group 11's Restaurant Order Management System according to the system specification and shared conventions. The module covers Browse Menu/Product, Search Dish, View Dish Details and Manage Dishes.

## 2. Implemented functions

### Customer/Guest
- Browse all visible dishes or filter by category.
- Sort by price, discount and ordered count in both ascending and descending order.
- Paginate results at 20 dishes per page.
- Search dish names case-insensitively and without requiring Vietnamese diacritics.
- View complete dish details and increment view count once.
- Show SOLD_OUT items while hiding DISCONTINUED items.

### Admin
- View all dishes, including discontinued ones.
- Search by dish code/name; filter by category/status; view status summary.
- Add dish with field validation.
- Update dish data without allowing Dish ID to change.
- Delete a dish physically only when it is not referenced by an order; otherwise change it to DISCONTINUED to preserve historical order details.
- Require the authenticated TV3 Auth object at the presentation-controller boundary.

## 3. Architecture

The implementation separates presentation controllers, service/business rules, repository/data access, models, and database adapters. `MenuService` does not contain SQL. `MenuRepository` uses parameterized SQL through `IDatabase`. SQLite is used for local tests; a MySQL adapter is provided for team integration.

## 4. Database alignment

The module follows the group's products/categories schema. Product `description` is the short description and `detail` is the full description. Price is handled as integer VND. Product data is supplied separately in `database/seed_menu.sql` so it can be appended to the shared seed after categories are inserted. The shared schema currently has no `created_at` for products, therefore newest-first ordering uses descending product code, documented in the README.

## 5. Verification

- Automated unit test suite: **90/90 tests passed** with `make -C tests/Unit/test_menu test`; CMake/CTest also passed (1/1 test target).
- Manual test workbook: `tests/testcases/TestCases_Menu.xlsx`, containing 62 test cases. Actual Result and Status are blank by design until executed on the integrated application.
- MySQL adapter: compile check is available with `-DTV1_WITH_MYSQL=ON`. A live MySQL instance test remains a group integration task.
- Figma: screen-to-controller mapping is documented in `FIGMA_INTEGRATION.md`. Actual Figma link and prototype screenshots must be added by the project owner.

## 6. Known integration boundaries

- This is the TV1 module only. Cart, checkout, account/session creation, order management and the actual web/UI runtime are outside TV1 scope.
- TV3 owns authentication. Use its current Auth object; do not copy test doubles into production.
- TV2 owns the shared final-price helper. This module includes a local fallback for stand-alone tests; use the official shared helper in the integrated repository.
- The MySQL adapter has not been tested against the team's live server in this environment.
