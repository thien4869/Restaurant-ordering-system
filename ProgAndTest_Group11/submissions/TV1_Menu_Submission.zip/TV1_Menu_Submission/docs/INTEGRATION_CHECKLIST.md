# Group integration checklist – TV1

- [ ] Pull current `main` and confirm latest `CONVENTIONS.md`.
- [ ] Copy only TV1-owned files; do not overwrite other members' shared files.
- [ ] Keep TV3's actual `Auth.h`/`User.h`; test doubles remain under `tests/Unit/test_menu/tv3_copy/` only.
- [ ] Connect real Admin Auth/session to `ManageDishController`.
- [ ] Replace local `PriceHelper` fallback with TV2's official shared helper if it exists.
- [ ] Confirm `products.sold` meaning with TV5; this module displays it as `Ordered` according to current convention.
- [ ] Confirm MySQL schema includes `discount`, `image`, `description`, `detail`, `views`, and `sold` fields.
- [ ] Append `database/seed_menu.sql` after shared category inserts; do not replace shared `seed.sql`.
- [ ] Build the MySQL adapter and run CRUD/search/view/delete tests against the shared database.
- [ ] Connect Figma screen interactions to the application's backend/API; Figma itself does not execute C++.
- [ ] Run the 64 manual test cases; fill Actual Result and Status only from real test runs.
- [ ] Capture evidence of build/test output and Git PR after running on the student's computer.
