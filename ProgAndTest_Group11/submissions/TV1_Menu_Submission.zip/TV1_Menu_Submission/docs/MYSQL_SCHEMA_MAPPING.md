# TV5 MySQL schema mapping

| C++ / Product field | MySQL field | Notes |
|---|---|---|
| `code` | `products.code` | Primary key; maximum 20 characters |
| `name` | `products.name` | Maximum 150 characters |
| `category_id` | `products.category_id` | Foreign key to `categories.category_id` |
| `image` | `products.image` | Relative path; nullable |
| `price` | `products.price` | `DECIMAL(12,0)`, integer VND |
| `discount` | `products.discount` | Integer 0–100 |
| `status` | `products.status` | `AVAILABLE`, `SOLD_OUT`, `DISCONTINUED` |
| `description` | `products.description` | Short description |
| `detail` | `products.detail` | Full description |
| `views` | `products.views` | View count |
| `sold` | `products.sold` | Displayed as Ordered per Group 11 convention |

Repository queries use `categories`, `products`, `order_details`, and `cart_items`. No `products.created_at` column is referenced because the shared schema supplied for this module does not define it. Product newest-first uses descending Dish ID as the agreed fallback.

The code's `MySqlDatabase` is an implementation of `IDatabase`; `MenuRepository` remains the single source of SQL and uses `?` placeholders/prepared statements. Configure connection values via the application environment/configuration, not committed source files.
