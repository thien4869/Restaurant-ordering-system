# TV1 requirements traceability

Basis: Group 11 `Restaurant_System_Specification_v1_2_edited` and `CONVENTIONS.md`.
The table links the assigned TV1 requirements to implementation entry points and the manual test workbook.

| Requirement / use case | Implementation | Manual test cases |
|---|---|---|
| Browse dishes by category; show 20 per page; retain SOLD_OUT and hide DISCONTINUED | `MenuService::browseMenu`, `MenuRepository`, `BrowseMenuController` | `TC-MENU-01`–`TC-MENU-04`, `TC-MENU-09`–`TC-MENU-12` |
| Sort by price, discount, or number of orders in ascending/descending order | `SortKey`, `MenuService`, `MenuRepository` | `TC-MENU-05`–`TC-MENU-08`, `TC-MENU-30`, `TC-MENU-63`–`TC-MENU-64` |
| Search name/partial name; ignore case and Vietnamese diacritics; exclude discontinued dishes | `TextHelper`, `MenuService::searchDishes`, `SearchDishController` | `TC-MENU-19`–`TC-MENU-29`, `TC-MENU-31`–`TC-MENU-32` |
| View dish details and increment views once | `MenuService::getDetail`, `DishDetailsController` | `TC-MENU-14`–`TC-MENU-18` |
| Admin-only dish list, search and filters | `ManageDishController`, `Tv3AuthRoleAdapter`, `MenuService::manageDishes` | `TC-MENU-33`–`TC-MENU-39` |
| Add dish with validation | `MenuService::addDish`, `MenuRepository` | `TC-MENU-40`–`TC-MENU-52` |
| Update dish without changing code/views/ordered count | `MenuService::updateDish`, `MenuRepository` | `TC-MENU-53`–`TC-MENU-57` |
| Delete dish while preserving order history; remove dangling cart reference when no order exists | `MenuService::deleteDish`, `MenuRepository` | `TC-MENU-58`–`TC-MENU-61` |
| Database failure handling | Repository/service error handling | `TC-MENU-12`, `TC-MENU-62` |

## External integration dependencies

- `TC-MENU-13`, `TC-MENU-16`, and `TC-MENU-18` include cart behaviour owned by TV2. The TV1 backend supplies dish data; the actual cart operation must be tested after TV2 is integrated.
- `TC-MENU-34` and all Admin cases require the real TV3 authentication/session object. Unit tests use test doubles only.
- Image upload tests (`TC-MENU-41`, `TC-MENU-49`–`TC-MENU-51`) require the application's file-upload layer to save validated JPG/PNG files to the relative path stored with the product. The C++ module validates metadata/path rules; it does not itself provide a browser upload endpoint.
- Live MySQL CRUD and concurrency behaviour still require execution against TV5's shared database. A successful adapter compile is not evidence of a live database connection.

## Known specification/schema gap

The supplied shared schema does not include `products.created_at`, while the use case requests newest-first ordering. This package currently uses descending product code as a documented fallback. Confirm whether TV5 will add a creation timestamp or the group accepts this fallback.
