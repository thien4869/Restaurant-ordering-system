# Figma – TV1 integration map

**Figma file URL:** add the team's actual Figma share URL here before submission.

The Figma file contains the visual design/prototype. This C++ module supplies menu data and business operations; a running application/API layer must invoke the controllers below. A Figma prototype alone does not execute the C++ backend.

| Figma view / interaction | Backend call | Data/behaviour to bind |
|---|---|---|
| Menu screen – initial load | `BrowseMenuController::execute(nullopt, SortKey::NEWEST, 1)` | `DishPage.items`, `categories`, `page`, `total_pages` |
| Select category | `BrowseMenuController::execute(categoryId, sort, page)` | Show dishes in that category; empty message when none |
| Change sort | Call Browse or Search controller with selected `SortKey` | Price/discount/ordered count can be ascending or descending |
| Change page | Call controller with selected page | 20 dishes per page; out-of-range page is clamped |
| Search | `SearchDishController::execute(keyword, sort, page)` | Case-insensitive, Vietnamese text with or without diacritics |
| Dish details | `DishDetailsController::execute(code)` | Bind returned product; `views` increases once when details are opened |
| Admin menu list | `ManageDishController::list(..., auth)` | Admin-only; supports search by code/name, category/status filter and summary counts |
| Add dish form | `ManageDishController::add(input, auth)` | Show validation messages; on success refresh list |
| Edit dish form | `ManageDishController::update(code, input, auth)` | Dish ID stays unchanged; views/ordered count are preserved |
| Delete confirmation | `ManageDishController::remove(code, auth)` | `DELETED` when no order references exist; `DISCONTINUED` when order history exists |

## Screen details / states

### Customer Menu
- Categories: All Dishes, Main Course, Appetizer, Dessert, Drink.
- Status badge: `Available` or `Sold Out`; discontinued dishes are hidden.
- Sort fields: Price (low/high), Discount (low/high), Number of Orders (low/high), and Newest first.
- Pagination: 20 items per page.
- Guest and signed-in Customer can use menu, search and details without authentication.

### Dish Details
Display: Dish ID, name, image, selling price, discount, status, views, ordered count, short description and full description. Keep sold-out dishes viewable but do not treat them as available for cart operations (cart is TV2's responsibility).

### Admin Manage Dishes
- Requires the real TV3 Auth session and `canAccessAdmin() == true`.
- Search: Dish ID or name.
- Filters: category and status.
- Add/edit fields: Dish ID (add only), name, category, price (VND integer >= 0), discount (0–100), status, image (JPG/PNG <= 2 MB), short description, full description.
- Delete confirmation: if referenced by `order_details`, mark `DISCONTINUED`; otherwise remove `cart_items` references and delete the product row.

## Messages
Use the English messages specified by Group 11 conventions so the application's visible output matches the manual test cases, including `No matching dish found`, `There are no dishes in this category yet`, `Please enter a keyword.`, and Admin validation/access messages.
