# TV3 Account – C++ console demonstration

Implements customer registration, login, simulated profile update, password recovery, and role/session checks using an in-memory repository. Includes unit checks and an Account test-case workbook.

## Build/run
From this directory:
```bash
g++ -std=c++17 src/main.cpp src/AccountService.cpp src/UserRepository.cpp -o account_demo
./account_demo
g++ -std=c++17 tests/tests_unit.cpp src/AccountService.cpp src/UserRepository.cpp -o account_tests
./account_tests
```
Windows: run the resulting `.exe` files.

## Limitations to disclose
This is a standalone C++ proof-of-concept and does not yet integrate with the team's full application, SQL database, GUI, or email service. Password hashing uses `std::hash` as a demonstration only, not a production password-hashing algorithm. Password recovery is simulated by directly resetting the password; it does not verify identity with a recovery token/email. Admin login is supported by the service only for a repository record whose role is set to `admin`; this demo does not seed an admin account. Do not present these limitations as completed production features.
