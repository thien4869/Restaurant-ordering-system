#include "UserRepository.h"
#include <algorithm>
#include <cctype>
static std::string norm(std::string s){ for(char& c:s)c=static_cast<char>(std::tolower(static_cast<unsigned char>(c))); return s; }
bool UserRepository::emailExists(const std::string& email) const { return findByEmail(email)!=nullptr; }
bool UserRepository::add(User user){ if(emailExists(user.email))return false; user.id=nextId++; users.push_back(user); return true; }
User* UserRepository::findByEmail(const std::string& email){ for(auto& u:users)if(norm(u.email)==norm(email))return &u; return nullptr; }
const User* UserRepository::findByEmail(const std::string& email) const { for(const auto& u:users)if(norm(u.email)==norm(email))return &u; return nullptr; }
