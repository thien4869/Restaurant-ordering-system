#include "AccountService.h"
#include <iostream>
int main(){ UserRepository repo; AccountService service(repo); Auth auth; std::string error;
 std::cout<<"TV3 Account module demo\n";
 if(service.registerUser("Demo Customer","customer@example.com","DemoPass123","DemoPass123","0900000000",error))std::cout<<"Register: PASS\n";else std::cout<<"Register: "<<error<<"\n";
 if(service.login("customer@example.com","DemoPass123",auth,error))std::cout<<"Login: PASS; role="<<auth.role()<<"\n";else std::cout<<error<<"\n";
 if(service.updateProfile(auth,"Customer Updated","0911111111",error))std::cout<<"Update profile: PASS\n";else std::cout<<error<<"\n";
 auth.logout();std::cout<<"Logout; role="<<auth.role()<<"\n";return 0; }
