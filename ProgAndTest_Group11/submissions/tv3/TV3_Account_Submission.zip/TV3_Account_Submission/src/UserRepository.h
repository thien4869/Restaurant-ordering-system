#ifndef USERREPOSITORY_H
#define USERREPOSITORY_H
#include "User.h"
#include <vector>
class UserRepository {
    std::vector<User> users;
    int nextId=1;
public:
    bool emailExists(const std::string& email) const;
    bool add(User user);
    User* findByEmail(const std::string& email);
    const User* findByEmail(const std::string& email) const;
};
#endif
