#include "../src/AccountService.h"
#include <cassert>
#include <iostream>
int main(){UserRepository repo;AccountService s(repo);Auth a;std::string e;
 assert(s.registerUser("Test","test@example.com","Password123","Password123","0901",e));
 assert(!s.registerUser("Other","TEST@example.com","Password123","Password123","0902",e));
 assert(!s.registerUser("Bad","bademail","Password123","Password123","0903",e));
 assert(!s.registerUser("Short","short@example.com","123","123","0904",e));
 assert(!s.registerUser("Mismatch","m@example.com","Password123","different","0905",e));
 assert(s.login("test@example.com","Password123",a,e));assert(a.isLoggedIn()&&a.role()=="customer");
 assert(s.updateProfile(a,"Updated","0912",e));assert(!s.updateProfile(a,"","",e));
 assert(!s.adminLogin("test@example.com","Password123",a,e));
 assert(s.recoverPassword("test@example.com","NewPassword123",e));a.logout();assert(!a.isLoggedIn()&&a.role()=="guest");
 assert(s.login("test@example.com","NewPassword123",a,e));
 std::cout<<"All Account unit tests passed.\n"; }
