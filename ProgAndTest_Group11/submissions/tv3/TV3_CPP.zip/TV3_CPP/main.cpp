#include "OrderService.h"
#include <iostream>
#include <iomanip>
#include <limits>

using namespace std;

void printOrder(const Order& order) {
    cout << "\nOrder: " << order.orderNumber << "\n"
         << "Recipient: " << order.recipientName << "\n"
         << "Phone: " << order.phone << "\n"
         << "Address: " << order.address << "\n"
         << "Payment: " << paymentTypeToString(order.paymentType)
         << " / " << paymentStatusToString(order.paymentStatus) << "\n"
         << "Status: " << statusToString(order.status) << "\n";
    for (const auto& d : order.details)
        cout << " - " << d.productName << " x " << d.quantity
             << " @ " << fixed << setprecision(0) << d.unitPrice
             << " = " << d.subtotal() << " VND\n";
    cout << "Total: " << fixed << setprecision(0) << order.totalAmount() << " VND\n";
}

int main() {
    OrderRepository repository;
    OrderService service(repository);
    const string email = "customer@example.com";
    vector<CartItem> sampleCart = {
        {"FD001", "Pho Bo", 2, 60000, 10},
        {"FD002", "Com Ga", 1, 50000, 0}
    };
    int choice;
    do {
        cout << "\n===== TV3 CUSTOMER ORDER =====\n"
             << "1. Checkout / Place Order\n"
             << "2. View Order History\n"
             << "3. View Order Details\n"
             << "4. Cancel Order\n"
             << "5. Exit\nChoice: ";
        if (!(cin >> choice)) return 0;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        if (choice == 1) {
            string name, phone, address, note, error;
            int payment;
            cout << "Recipient name: "; getline(cin, name);
            cout << "Phone: "; getline(cin, phone);
            cout << "Address: "; getline(cin, address);
            cout << "Note: "; getline(cin, note);
            cout << "Payment (1=CASH, 2=ONLINE): "; cin >> payment;
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            Order created;
            PaymentType type = payment == 2 ? PaymentType::ONLINE : PaymentType::CASH;
            if (!service.checkout(email, name, phone, address, note, type, sampleCart, created, error)) {
                cout << "Checkout failed: " << error << "\n";
            } else {
                cout << "Order created!\n";
                if (type == PaymentType::ONLINE) {
                    int result;
                    cout << "Simulate online payment (1=success, 0=fail): ";
                    cin >> result;
                    cin.ignore(numeric_limits<streamsize>::max(), '\n');
                    service.simulateOnlinePayment(email, created.orderNumber, result == 1);
                    const Order* updated = service.details(email, created.orderNumber);
                    if (updated) printOrder(*updated);
                } else printOrder(created);
            }
        } else if (choice == 2) {
            auto orders = service.history(email);
            if (orders.empty()) cout << "You have no orders yet.\n";
            for (const auto& order : orders)
                cout << order.orderNumber << " | " << order.totalAmount()
                     << " VND | " << statusToString(order.status) << "\n";
        } else if (choice == 3) {
            string number;
            cout << "Order number: "; getline(cin, number);
            const Order* order = service.details(email, number);
            if (order) printOrder(*order);
            else cout << "Order not found or access denied.\n";
        } else if (choice == 4) {
            string number, message;
            cout << "Order number: "; getline(cin, number);
            if (service.cancel(email, number, message)) cout << message << "\n";
            else cout << message << "\n";
        }
    } while (choice != 5);
    return 0;
}
