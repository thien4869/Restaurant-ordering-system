#ifndef ORDER_H
#define ORDER_H

#include <string>
#include <vector>

enum class OrderStatus { NEW, CONFIRMED, IN_TRANSIT, COMPLETED, CANCELED };
enum class PaymentType { CASH, ONLINE };
enum class PaymentStatus { PENDING, PAID, FAILED };

struct OrderDetail {
    std::string productCode;
    std::string productName;
    int quantity;
    double unitPrice;
    double subtotal() const { return quantity * unitPrice; }
};

struct Order {
    std::string orderNumber;
    std::string userEmail;
    std::string recipientName;
    std::string phone;
    std::string address;
    std::string note;
    PaymentType paymentType;
    PaymentStatus paymentStatus;
    OrderStatus status;
    std::vector<OrderDetail> details;
    double totalAmount() const;
};

std::string statusToString(OrderStatus status);
std::string paymentTypeToString(PaymentType type);
std::string paymentStatusToString(PaymentStatus status);

#endif
