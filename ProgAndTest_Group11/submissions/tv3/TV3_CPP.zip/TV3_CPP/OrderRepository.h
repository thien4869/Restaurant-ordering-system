#ifndef ORDERREPOSITORY_H
#define ORDERREPOSITORY_H
#include "Order.h"
#include <vector>
#include <string>

class OrderRepository {
private:
    std::vector<Order> orders;
public:
    void add(const Order& order);
    std::vector<Order> getByUser(const std::string& email) const;
    const Order* findByNumber(const std::string& number, const std::string& email) const;
    Order* findMutableByNumber(const std::string& number, const std::string& email);
};
#endif
