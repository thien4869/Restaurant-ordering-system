#include "OrderRepository.h"

void OrderRepository::add(const Order& order) { orders.push_back(order); }
std::vector<Order> OrderRepository::getByUser(const std::string& email) const {
    std::vector<Order> result;
    for (const auto& order : orders) if (order.userEmail == email) result.push_back(order);
    return result;
}
const Order* OrderRepository::findByNumber(const std::string& number, const std::string& email) const {
    for (const auto& order : orders)
        if (order.orderNumber == number && order.userEmail == email) return &order;
    return nullptr;
}
Order* OrderRepository::findMutableByNumber(const std::string& number, const std::string& email) {
    for (auto& order : orders)
        if (order.orderNumber == number && order.userEmail == email) return &order;
    return nullptr;
}
