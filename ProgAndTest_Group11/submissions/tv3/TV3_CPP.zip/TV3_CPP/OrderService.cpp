#include "OrderService.h"
#include <ctime>
#include <iomanip>
#include <sstream>

OrderService::OrderService(OrderRepository& repository) : repo(repository), sequence(1) {}

std::string OrderService::makeOrderNumber() {
    std::time_t now = std::time(nullptr);
    std::tm* tmNow = std::localtime(&now);
    std::ostringstream date, seq;
    date << std::put_time(tmNow, "%Y%m%d");
    seq << std::setw(4) << std::setfill('0') << sequence++;
    return "ORD-" + date.str() + "-" + seq.str();
}

bool OrderService::validateCheckout(const std::string& name, const std::string& phone,
                                   const std::string& address, const std::vector<CartItem>& cart,
                                   std::string& error) const {
    if (name.empty()) { error = "Recipient name is required."; return false; }
    if (phone.empty()) { error = "Phone number is required."; return false; }
    if (address.empty()) { error = "Delivery address is required."; return false; }
    if (cart.empty()) { error = "Your cart is empty."; return false; }
    for (const auto& item : cart) {
        if (item.quantity <= 0) { error = "Quantity must be greater than zero."; return false; }
        if (item.unitPrice < 0 || item.discountPercent < 0 || item.discountPercent > 100) {
            error = "Invalid product price or discount."; return false;
        }
    }
    error.clear();
    return true;
}

bool OrderService::checkout(const std::string& email, const std::string& name, const std::string& phone,
                           const std::string& address, const std::string& note,
                           PaymentType paymentType, const std::vector<CartItem>& cart,
                           Order& created, std::string& error) {
    if (email.empty()) { error = "Login is required."; return false; }
    if (!validateCheckout(name, phone, address, cart, error)) return false;
    created.orderNumber = makeOrderNumber();
    created.userEmail = email;
    created.recipientName = name;
    created.phone = phone;
    created.address = address;
    created.note = note;
    created.paymentType = paymentType;
    created.paymentStatus = PaymentStatus::PENDING;
    created.status = OrderStatus::NEW;
    created.details.clear();
    for (const auto& item : cart) {
        double finalPrice = item.unitPrice * (1.0 - item.discountPercent / 100.0);
        created.details.push_back({item.productCode, item.productName, item.quantity, finalPrice});
    }
    repo.add(created);
    error.clear();
    return true;
}

std::vector<Order> OrderService::history(const std::string& email) const {
    return repo.getByUser(email);
}
const Order* OrderService::details(const std::string& email, const std::string& number) const {
    return repo.findByNumber(number, email);
}
bool OrderService::cancel(const std::string& email, const std::string& number, std::string& message) {
    Order* order = repo.findMutableByNumber(number, email);
    if (!order) { message = "Order not found or access denied."; return false; }
    if (order->status != OrderStatus::NEW) { message = "Only NEW orders can be canceled."; return false; }
    order->status = OrderStatus::CANCELED;
    message = "Order canceled successfully.";
    return true;
}
bool OrderService::simulateOnlinePayment(const std::string& email, const std::string& number, bool success) {
    Order* order = repo.findMutableByNumber(number, email);
    if (!order || order->paymentType != PaymentType::ONLINE || order->status != OrderStatus::NEW) return false;
    order->paymentStatus = success ? PaymentStatus::PAID : PaymentStatus::FAILED;
    return success;
}
