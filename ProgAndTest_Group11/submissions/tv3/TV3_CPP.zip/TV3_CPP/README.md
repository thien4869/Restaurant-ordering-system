# TV3 C++ - Checkout and Customer Orders (Console demo)

## Scope
- Checkout validation and order creation
- Order and order detail records (in-memory demo)
- Discount calculation on the server-side service
- Simulated CASH / ONLINE payment
- Customer order history and detail view
- Cancel only NEW orders
- Owner-only lookup enforced by email passed to service

## Important limitation
This is a standalone console demonstration using in-memory storage and a sample cart.
It is not connected to the group's database, login/session, or TV2 cart. Integrate repository
and session/cart data with the actual group project before claiming database integration.

## Build
Compile all .cpp files with C++17:
```bash
g++ -std=c++17 main.cpp Order.cpp OrderRepository.cpp OrderService.cpp -o tv3
./tv3
```
On Windows:
```bash
g++ -std=c++17 main.cpp Order.cpp OrderRepository.cpp OrderService.cpp -o tv3.exe
tv3.exe
```

Demo email is customer@example.com. Sample cart: Pho Bo x2 (60,000 with 10% discount), Com Ga x1 (50,000).

## Group conventions represented
Order statuses: NEW, CONFIRMED, IN_TRANSIT, COMPLETED, CANCELED.
Payment types: CASH, ONLINE.
Payment statuses: PENDING, PAID, FAILED.
Order number format: ORD-YYYYMMDD-NNNN.

The sequence counter is only demo-grade and resets when the program starts.
Production integration should generate unique order IDs safely and use a database transaction.
