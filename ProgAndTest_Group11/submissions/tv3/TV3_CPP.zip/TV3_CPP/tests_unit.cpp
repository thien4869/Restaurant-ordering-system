#include "OrderService.h"
#include <cassert>
#include <iostream>

int main() {
    OrderRepository repo;
    OrderService service(repo);
    std::vector<CartItem> cart = {{"FD01","Dish",2,100,10}};
    std::string error;
    assert(service.validateCheckout("A","123","Address",cart,error));
    assert(!service.validateCheckout("","","",cart,error));
    assert(!service.validateCheckout("A","123","Address",{},error));

    Order order;
    assert(service.checkout("a@x.com","A","123","Address","",PaymentType::CASH,cart,order,error));
    assert(order.details.size()==1);
    assert(order.totalAmount()==180);
    assert(service.details("a@x.com",order.orderNumber)!=nullptr);
    assert(service.details("b@x.com",order.orderNumber)==nullptr);

    std::string message;
    assert(service.cancel("a@x.com",order.orderNumber,message));
    assert(service.details("a@x.com",order.orderNumber)->status==OrderStatus::CANCELED);
    assert(!service.cancel("a@x.com",order.orderNumber,message));
    std::cout << "All TV3 unit checks passed.\\n";
    return 0;
}
