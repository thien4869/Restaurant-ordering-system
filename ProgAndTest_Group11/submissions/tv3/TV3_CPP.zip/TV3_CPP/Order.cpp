#include "Order.h"

double Order::totalAmount() const {
    double total = 0;
    for (const auto& item : details) total += item.subtotal();
    return total;
}

std::string statusToString(OrderStatus status) {
    switch (status) {
        case OrderStatus::NEW: return "NEW";
        case OrderStatus::CONFIRMED: return "CONFIRMED";
        case OrderStatus::IN_TRANSIT: return "IN_TRANSIT";
        case OrderStatus::COMPLETED: return "COMPLETED";
        case OrderStatus::CANCELED: return "CANCELED";
    }
    return "UNKNOWN";
}
std::string paymentTypeToString(PaymentType type) {
    return type == PaymentType::CASH ? "CASH" : "ONLINE";
}
std::string paymentStatusToString(PaymentStatus status) {
    switch (status) {
        case PaymentStatus::PENDING: return "PENDING";
        case PaymentStatus::PAID: return "PAID";
        case PaymentStatus::FAILED: return "FAILED";
    }
    return "UNKNOWN";
}
