#ifndef ORDERSERVICE_H
#define ORDERSERVICE_H
#include "OrderRepository.h"
#include <string>
#include <vector>

struct CartItem {
    std::string productCode;
    std::string productName;
    int quantity;
    double unitPrice;
    int discountPercent;
};

class OrderService {
private:
    OrderRepository& repo;
    int sequence;
    std::string makeOrderNumber();
public:
    explicit OrderService(OrderRepository& repository);
    bool validateCheckout(const std::string& name, const std::string& phone,
                          const std::string& address, const std::vector<CartItem>& cart,
                          std::string& error) const;
    bool checkout(const std::string& email, const std::string& name, const std::string& phone,
                  const std::string& address, const std::string& note,
                  PaymentType paymentType, const std::vector<CartItem>& cart,
                  Order& created, std::string& error);
    std::vector<Order> history(const std::string& email) const;
    const Order* details(const std::string& email, const std::string& number) const;
    bool cancel(const std::string& email, const std::string& number, std::string& message);
    bool simulateOnlinePayment(const std::string& email, const std::string& number, bool success);
};
#endif
