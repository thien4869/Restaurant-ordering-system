## Nội dung
<!-- Làm gì, thuộc use-case nào -->

## Kiểm tra trước khi gộp
- [ ] Đã chạy được bằng `docker compose up`
- [ ] Đã viết/chạy unit test
- [ ] Đã thêm test case vào file Excel
- [ ] Tên bảng, cột, giá trị trạng thái đúng `docs/CONVENTIONS.md`
