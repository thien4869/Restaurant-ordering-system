---
name: Báo lỗi
about: Ghi lỗi tìm được khi kiểm thử
title: "[BUG][Module] mô tả ngắn"
labels: bug
---

**Module / Use-case:**

**Các bước tái hiện:**
1.
2.

**Kết quả mong đợi:**

**Kết quả thực tế:**

**Mã test case liên quan:** (ví dụ TC-CART-03)
